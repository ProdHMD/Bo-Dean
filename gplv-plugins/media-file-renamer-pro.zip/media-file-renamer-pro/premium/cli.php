<?php

class MeowPro_MFRH_CLI extends WP_CLI_Command {

	private $core = null;

	public function __construct( $pro = null, $admin = null, $core = null ) {
		$this->core = $core;
	}

	function help() {
		$commands = [
			'help'           => 'Display this help message.',
			'list'           => 'List all pending renames. Use --format=csv for CSV output.',
			'info [ids]'     => 'Display info about media files. Optionally pass Media IDs.',
			'rename_auto'    => 'Rename one or more media files automatically. Usage: rename_auto <id> [id...]',
			'rename_manual'  => 'Rename a media file manually. Usage: rename_manual <id> <filename>',
			'rename_all'     => 'Rename all unlocked media files automatically. Use --dry-run to preview.',
			'lock'           => 'Lock one or more media files. Usage: lock <id> [id...]',
			'lock_all'       => 'Lock all media files.',
			'unlock'         => 'Unlock one or more media files. Usage: unlock <id> [id...]',
			'unlock_all'     => 'Unlock all media files.',
			'manual_title'   => 'Set the title of a media file. Usage: manual_title <id> <title>',
			'manual_alt'     => 'Set the alt text of a media file. Usage: manual_alt <id> <alt text>',
			'manual_caption' => 'Set the caption of a media file. Usage: manual_caption <id> <caption>',
			'manual_desc'    => 'Set the description of a media file. Usage: manual_desc <id> <description>',
			'set_methods'    => 'Set rename methods. Usage: set_methods <primary> [secondary] [tertiary]',
		];

		WP_CLI::line( '' );
		WP_CLI::line( 'Media File Renamer CLI Commands:' );
		WP_CLI::line( '' );

		foreach ( $commands as $command => $description ) {
			WP_CLI::line( sprintf( '  wp mfrh %-16s %s', $command, $description ) );
		}

		WP_CLI::line( '' );
	}

	/**
	 * Set the rename methods (primary, secondary, tertiary).
	 *
	 * ## OPTIONS
	 * Use "none" to disable, or " " (space) to keep current.
	 * 
	 * options:
	 *   - none
	 *   - media_title
	 *   - alt_text
	 *   - post_title
	 *   - post_acf_field
	 *   - anonymize_md5
	 *   - vision
	 *
	 * ## EXAMPLES
	 *
	 *     # Set primary method only
	 *     wp mfrh set_methods media_title
	 *
	 *     # Set primary and secondary
	 *     wp mfrh set_methods media_title alt_text
	 *
	 *     # Set all three methods
	 *     wp mfrh set_methods media_title alt_text post_title
	 *
	 *     # Keep primary unchanged, set secondary to alt_text
	 *     wp mfrh set_methods " " alt_text
	 *
	 *     # Disable all methods
	 *     wp mfrh set_methods none none none
	 *
	 * @param array $args Positional arguments.
	 */
	function set_methods( $args ) {
		if ( empty( $args ) ) {
			WP_CLI::error( 'This command requires at least one method argument.' );
			return;
		}

		$valid_methods = [ 'none', 'media_title', 'alt_text', 'post_title', 'post_acf_field', 'anonymize_md5', 'vision' ];
		$option_keys = [ 'auto_rename', 'auto_rename_secondary', 'auto_rename_tertiary' ];
		$labels = [ 'Primary', 'Secondary', 'Tertiary' ];

		$options = $this->core->get_all_options();
		$changes = [];

		for ( $i = 0; $i < 3; $i++ ) {
			if ( !isset( $args[ $i ] ) ) {
				continue;
			}

			$method = trim( $args[ $i ] );

			// Space or empty means skip (keep current value)
			if ( $method === '' ) {
				continue;
			}

			if ( !in_array( $method, $valid_methods ) ) {
				WP_CLI::warning( sprintf( '%s method "%s" is not valid. Skipping.', $labels[ $i ], $method ) );
				continue;
			}

			$options[ $option_keys[ $i ] ] = $method;
			$changes[] = sprintf( '%s: %s', $labels[ $i ], $method );
		}

		if ( empty( $changes ) ) {
			WP_CLI::warning( 'No changes made.' );
			return;
		}

		$this->core->update_options( $options );
		WP_CLI::success( 'Methods updated: ' . implode( ', ', $changes ) );
	}

	function list( $args = [], $assoc_args = [] ) {
		global $wpdb;

		$format = isset( $assoc_args['format'] ) ? $assoc_args['format'] : 'table';

		// Get all pending media IDs
		$ids = $wpdb->get_col( "
			SELECT p.ID 
			FROM $wpdb->posts p
			INNER JOIN $wpdb->postmeta pm ON pm.post_id = p.ID 
				AND pm.meta_key = '_require_file_renaming' 
				AND pm.meta_value IS NOT NULL
			WHERE p.post_type = 'attachment' 
				AND p.post_status = 'inherit'
			ORDER BY p.ID DESC
		" );

		if ( empty( $ids ) ) {
			WP_CLI::success( 'No pending renames found.' );
			return;
		}

		$rows = [];

		foreach ( $ids as $mediaId ) {
			$post = get_post( $mediaId, ARRAY_A );
			if ( !$post ) {
				continue;
			}

			$file_path = get_post_meta( $mediaId, '_wp_attached_file', true );
			$current_filename = basename( $file_path );

			// Try to get the ideal filename
			$ideal_filename = '';

			// First check cached ideal filename
			$cached_ideal = get_post_meta( $mediaId, '_mfrh_ideal_filename', true );
			if ( !empty( $cached_ideal ) ) {
				$ideal_filename = $cached_ideal;
			} else {
				// Use check_attachment to compute the ideal filename (preview mode)
				$output = [];
				$result = $this->core->check_attachment( $post, $output, null, false, true );
				if ( $result && isset( $output['ideal_filename'] ) ) {
					$ideal_filename = $output['ideal_filename'];
				} elseif ( isset( $output['proposed_filename'] ) ) {
					$ideal_filename = $output['proposed_filename'];
				}
			}

			$rows[] = [
				'ID'               => $mediaId,
				'Current Filename' => $current_filename,
				'Ideal Filename'   => $ideal_filename ?: '(method unavailable)',
			];
		}

		if ( empty( $rows ) ) {
			WP_CLI::success( 'No pending renames found.' );
			return;
		}

		if ( $format === 'csv' ) {
			// CSV output
			$headers = array_keys( $rows[0] );
			WP_CLI::line( implode( ',', $headers ) );
			foreach ( $rows as $row ) {
				$escaped = array_map( function( $value ) {
					// Escape quotes and wrap in quotes if contains comma or quote
					if ( strpos( $value, ',' ) !== false || strpos( $value, '"' ) !== false ) {
						return '"' . str_replace( '"', '""', $value ) . '"';
					}
					return $value;
				}, array_values( $row ) );
				WP_CLI::line( implode( ',', $escaped ) );
			}
		} else {
			// Table output
			$headers = [ 'ID', 'Current Filename', 'Ideal Filename' ];
			$tableRows = [];
			$tableRows[] = $headers;

			foreach ( $rows as $row ) {
				$tableRows[] = array_values( $row );
			}

			$numCols = count( $headers );
			$colWidths = [];
			for ( $col = 0; $col < $numCols; $col++ ) {
				$maxLen = 0;
				foreach ( $tableRows as $tableRow ) {
					$cellLen = strlen( (string) $tableRow[ $col ] );
					if ( $cellLen > $maxLen ) {
						$maxLen = $cellLen;
					}
				}
				$colWidths[] = $maxLen;
			}

			$create_separator = function( $colWidths ) {
				$line = '+';
				foreach ( $colWidths as $width ) {
					$line .= str_repeat( '-', $width + 2 ) . '+';
				}
				return $line;
			};

			$separator = $create_separator( $colWidths );
			WP_CLI::line( $separator );

			$headerLine = '|';
			for ( $col = 0; $col < $numCols; $col++ ) {
				$headerLine .= ' ' . str_pad( $tableRows[0][ $col ], $colWidths[ $col ] ) . ' |';
			}
			WP_CLI::line( $headerLine );
			WP_CLI::line( $separator );

			for ( $i = 1, $total = count( $tableRows ); $i < $total; $i++ ) {
				$rowLine = '|';
				for ( $col = 0; $col < $numCols; $col++ ) {
					$rowLine .= ' ' . str_pad( (string) $tableRows[ $i ][ $col ], $colWidths[ $col ] ) . ' |';
				}
				WP_CLI::line( $rowLine );
			}
			WP_CLI::line( $separator );
		}

		WP_CLI::success( sprintf( 'Found %d pending rename(s).', count( $rows ) ) );
	}

  function rename_auto( $args ) {
    if ( empty( $args ) ) {
      WP_CLI::error( 'This command requires one or more Media IDs.' );
      return;
    }
    foreach ( $args as $mediaId ) {
      mfrh_rename( $mediaId );
      WP_CLI::line( "Renamed Media ID $mediaId automatically." );
    }
  }

  function rename_manual( $args ) {
    if ( empty( $args ) || count( $args ) !== 2 ) {
      WP_CLI::error( 'This command requires a Media ID and a filename.' );
      return;
    }
    $mediaId = $args[0];
    $filename = $args[1];
    mfrh_rename( $mediaId, $filename );
    WP_CLI::line( "Renamed Media ID $mediaId manually." );
  }

  function unlock_all() {
    global $wpdb;
    $wpdb->query( "DELETE FROM $wpdb->postmeta WHERE meta_key = '_manual_file_renaming'" );
  }

  function unlock( $args ) {
    if ( empty( $args ) ) {
      WP_CLI::error( 'This command requires one or more Media IDs.' );
      return;
    }
    global $wpdb;
    foreach ( $args as $mediaId ) {
      $wpdb->query( $wpdb->prepare( "DELETE FROM $wpdb->postmeta WHERE post_id = %d AND meta_key = '_manual_file_renaming'", $mediaId ) );
      WP_CLI::line( "Unlocked Media ID $mediaId." );
    }
  }

  function lock( $args ) {
    if ( empty( $args ) ) {
      WP_CLI::error( 'This command requires one or more Media IDs.' );
      return;
    }
    global $wpdb;
    foreach ( $args as $mediaId ) {
      update_post_meta( $mediaId, '_manual_file_renaming', 1 );
      WP_CLI::line( "Locked Media ID $mediaId." );
    }
  }

  function lock_all() {
    global $wpdb;
    $ids = $wpdb->get_col( "SELECT p.ID FROM $wpdb->posts p WHERE post_status = 'inherit' AND post_type = 'attachment'" );
    foreach ( $ids as $mediaId ) {
      update_post_meta( $mediaId, '_manual_file_renaming', 1 );
      WP_CLI::line( "Locked Media ID $mediaId." );
    }
  }

  function rename_all( $args = [], $assoc_args = [] ) {
    global $wpdb;
    $dry_run = isset( $assoc_args['dry-run'] );

    $ids = $wpdb->get_col( "SELECT p.ID FROM $wpdb->posts p WHERE post_status = 'inherit' AND post_type = 'attachment'" );
    $idsToRemove = $wpdb->get_col( "SELECT m.post_id FROM $wpdb->postmeta m 
      WHERE m.meta_key = '_manual_file_renaming' and m.meta_value = 1" );
    $ids = array_values( array_diff( $ids, $idsToRemove ) );

    if ( $dry_run ) {
      WP_CLI::line( 'Dry run mode - no changes will be made.' );
      WP_CLI::line( '' );
      $count = 0;
      foreach ( $ids as $mediaId ) {
        $post = get_post( $mediaId, ARRAY_A );
        if ( !$post ) {
          continue;
        }
        $output = [];
        $result = $this->core->check_attachment( $post, $output, null, false, true );
        if ( $result && isset( $output['current_filename'] ) && isset( $output['ideal_filename'] ) ) {
          WP_CLI::line( sprintf(
            "ID %d: %s -> %s",
            $mediaId,
            $output['current_filename'],
            $output['ideal_filename']
          ) );
          $count++;
        }
      }
      WP_CLI::success( sprintf( '%d file(s) would be renamed.', $count ) );
    } else {
      foreach ( $ids as $mediaId ) {
        mfrh_rename( $mediaId );
        WP_CLI::line( "Renamed Media ID $mediaId automatically." );
      }
    }
  }

  function info( $args ) {

		$query_args = array(
			'post_type'      => 'attachment',
			'post_status'    => 'inherit',
			'posts_per_page' => -1,
		);


		if ( ! empty( $args ) ) {
			$query_args['post__in'] = $args;
		}

		$attachments = get_posts( $query_args );

		if ( empty( $attachments ) ) {
			WP_CLI::line( 'No media files found.' );
			return;
		}

		$rows    = array();
		$headers = array( 'Title', 'Filename', 'ID', 'Locked' );
		$rows[]  = $headers;

		foreach ( $attachments as $attachment ) {
			$file_path = get_post_meta( $attachment->ID, '_wp_attached_file', true );
			$filename  = basename( $file_path );
			$is_locked = get_post_meta( $attachment->ID, '_manual_file_renaming', true ) == 1 ? 'Yes' : 'No';
			$rows[]    = array( $attachment->post_title, $filename, $attachment->ID, $is_locked );
		}

		$numCols   = count( $headers );
		$colWidths = array();
		for ( $col = 0; $col < $numCols; $col++ ) {
			$maxLen = 0;
			foreach ( $rows as $row ) {
				$cellLen = strlen( (string) $row[ $col ] );
				if ( $cellLen > $maxLen ) {
					$maxLen = $cellLen;
				}
			}
			$colWidths[] = $maxLen;
		}

		// Helper to create a separator row
		$create_separator = function( $colWidths ) {
			$line = '+';
			foreach ( $colWidths as $width ) {
				$line .= str_repeat( '-', $width + 2 ) . '+';
			}
			return $line;
		};

		$separator = $create_separator( $colWidths );
		WP_CLI::line( $separator );

		$headerLine = '|';
		for ( $col = 0; $col < $numCols; $col++ ) {
			$headerLine .= ' ' . str_pad( $rows[0][ $col ], $colWidths[ $col ] ) . ' |';
		}
		WP_CLI::line( $headerLine );
		WP_CLI::line( $separator );

		for ( $i = 1, $total = count( $rows ); $i < $total; $i++ ) {
			$rowLine = '|';
			for ( $col = 0; $col < $numCols; $col++ ) {
				$rowLine .= ' ' . str_pad( (string) $rows[ $i ][ $col ], $colWidths[ $col ] ) . ' |';
			}
			WP_CLI::line( $rowLine );
		}
		WP_CLI::line( $separator );
	}

	function manual_alt( $args ) {
		if ( empty( $args ) || count( $args ) < 2 ) {
			WP_CLI::error( 'This command requires a Media ID and an alt text value.' );
			return;
		}
		$mediaId = $args[0];
		$alt = implode( ' ', array_slice( $args, 1 ) );
		$result = $this->core->update_media( $mediaId, null, $alt, null, null, 'manual' );
		if ( !empty( $result['errors'] ) ) {
			WP_CLI::error( "Failed to update alt text for Media ID $mediaId: " . implode( ', ', $result['errors'] ) );
		} else {
			WP_CLI::success( "Updated alt text for Media ID $mediaId." );
		}
	}

	function manual_title( $args ) {
		if ( empty( $args ) || count( $args ) < 2 ) {
			WP_CLI::error( 'This command requires a Media ID and a title value.' );
			return;
		}
		$mediaId = $args[0];
		$title = implode( ' ', array_slice( $args, 1 ) );
		$result = $this->core->update_media( $mediaId, $title, null, null, null, 'manual' );
		if ( !empty( $result['errors'] ) ) {
			WP_CLI::error( "Failed to update title for Media ID $mediaId: " . implode( ', ', $result['errors'] ) );
		} else {
			WP_CLI::success( "Updated title for Media ID $mediaId." );
		}
	}

	function manual_caption( $args ) {
		if ( empty( $args ) || count( $args ) < 2 ) {
			WP_CLI::error( 'This command requires a Media ID and a caption value.' );
			return;
		}
		$mediaId = $args[0];
		$caption = implode( ' ', array_slice( $args, 1 ) );
		$result = $this->core->update_media( $mediaId, null, null, null, $caption, 'manual' );
		if ( !empty( $result['errors'] ) ) {
			WP_CLI::error( "Failed to update caption for Media ID $mediaId: " . implode( ', ', $result['errors'] ) );
		} else {
			WP_CLI::success( "Updated caption for Media ID $mediaId." );
		}
	}

	function manual_desc( $args ) {
		if ( empty( $args ) || count( $args ) < 2 ) {
			WP_CLI::error( 'This command requires a Media ID and a description value.' );
			return;
		}
		$mediaId = $args[0];
		$description = implode( ' ', array_slice( $args, 1 ) );
		$result = $this->core->update_media( $mediaId, null, null, $description, null, 'manual' );
		if ( !empty( $result['errors'] ) ) {
			WP_CLI::error( "Failed to update description for Media ID $mediaId: " . implode( ', ', $result['errors'] ) );
		} else {
			WP_CLI::success( "Updated description for Media ID $mediaId." );
		}
	}

}

?>