=== AI Engine (Pro) - The Chatbot and AI Framework for WordPress ===
Contributors: TigrouMeow
Tags: ai, chatbot, gpt, claude, openai
Donate link: https://www.patreon.com/meowapps
Requires at least: 6.0
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 3.3.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

AI meets WordPress. Your site can now chat, write poetry, solve problems, and maybe make you coffee.

== Description ==

**AI Engine connects WordPress with AI models.** Build intelligent chatbots, generate content, create AI forms, and automate tasks. All from your WordPress dashboard.

Please make sure you read the [disclaimer](https://meowapps.com/ai-engine/disclaimer/). For more information, check the official website of [AI Engine](https://meowapps.com/ai-engine/).

== Quick Intro ==

Hello! ☀️ I built AI Engine to bring OpenAI, Claude, and other AI models into WordPress. Create chatbots that understand your content, generate posts in your voice, translate instantly, create images, or build custom AI tools.

For developers: internal APIs, REST endpoints, function calling, and MCP support. Build AI features, automate workflows, or create SaaS applications on WordPress.

Feeling overwhelmed? 🤪 Start simple: Create a chatbot. Then connect ChatGPT through MCP, giving AI direct access to your site. Add [SEO Engine](https://wordpress.org/plugins/seo-engine/) and watch it manage SEO in ways you never imagined. You can even connect AI Engine to multiple WordPress sites and manage them all through conversation.

You'll be having a blast before you've explored everything.

== Core Modules ==

🤖 **Chatbots**
Create intelligent chatbots with customizable themes, realtime audio, and multi-file support. Features modular UI Builder, conversation memory, and MacOS-style components.

🎨 **Content & Images**
Generate content, translate text, create images from prompts, and use Copilot in the WordPress editor for instant suggestions and rewrites.

📝 **AI Forms (Pro)**
Build custom AI-powered forms that handle text, images, audio, or file uploads. Create advanced apps with conditional logic.

🧠 **Knowledge & Embeddings (Pro)**
Fine-tune models, create embeddings, and build knowledge bases from PDFs. Connect with Pinecone, Chroma, Qdrant, or OpenAI Vector Store for semantic search.

🔧 **Function Calling**
Connect AI to WordPress functions, WooCommerce, appointments, or custom APIs. Let AI interact with your site's data and services in real-time.

🔌 **Developer Tools**
Internal APIs, REST endpoints, MCP support, and extensive hooks. Build AI-driven features, automate workflows, or create SaaS applications.

== 🤖 Chatbots ==

Transform visitor interactions with intelligent, customizable chatbots.

**Features:**

* Modular UI Builder with containers, headers, footers
* Customizable themes and MacOS-style components
* Realtime audio conversations
* Multi-file upload support
* Discussion memory and history
* Cross-site embedding
* GDPR compliance tools

== 🎨 Content & Images ==

Create, refine, and visualize content with AI assistance.

**Content Generation:**

* Generate posts in your voice
* Translate naturally across languages
* Copilot integration in WordPress editor
* Real-time suggestions and rewrites

**Image Tools:**

* Create images from text prompts
* Edit existing images with AI
* Vision AI for image analysis
* Automatic alt text generation

== 📝 AI Forms (Pro) ==

Build powerful AI-driven forms and applications.

**Capabilities:**

* Text, image, audio, and file inputs
* Conditional logic and validation
* Custom AI-powered apps
* Multi-step workflows
* Result templates

== 🧠 Knowledge & Embeddings (Pro) ==

Create intelligent knowledge bases and semantic search.

**Vector Databases:**

* Chroma, Qdrant, Pinecone
* OpenAI Vector Store
* Automatic synchronization
* Dimension validation

**Smart Features:**

* PDF import with auto-chunking
* AI-powered search (Simple, Context-Aware, Smart)
* Content classification
* Personalized recommendations

== 🔧 Developer Tools ==

Extend WordPress with AI capabilities.

**APIs:**

* Internal API for plugin integration
* REST API for external applications
* MCP (Model Context Protocol) support
* Function calling framework

**Integration:**

* Works with SEO Engine, Social Engine, Code Engine
* Media File Renamer support
* Custom shortcodes and hooks
* Extensive WordPress filters

**Resources:**

* [Code Examples & Customization](https://ai.thehiddendocs.com/examples/)

== MCP (Model Context Protocol) ==

AI Engine turns your WordPress site into an intelligent MCP server. AI agents like ChatGPT and Claude can connect directly, browse content, edit posts, manage media, and handle complex tasks through natural conversation.

**What AI Agents Can Do:**

* Create and edit posts
* Moderate comments
* Install and manage plugins
* Customize themes
* Check SEO and analytics
* Manage media files

**Setup Guides:**

* [General MCP Overview](https://ai.thehiddendocs.com/mcp/)
* [MCP with ChatGPT](https://ai.thehiddendocs.com/mcp/mcp-server-chatgpt/)
* [MCP with Claude](https://ai.thehiddendocs.com/mcp/mcp-server-claude/)

**Plugin Integration:**

Other plugins add their features to the MCP system:

* [SEO Engine](https://wordpress.org/plugins/seo-engine/) - Let AI analyze and optimize your content, fix SEO issues, and manage meta data
* [Social Engine](https://wordpress.org/plugins/social-engine/) - AI can schedule posts, manage social media, and create social content
* [Code Engine](https://wordpress.org/plugins/code-engine/) - Give AI access to code snippets and custom functions

AI Engine can also connect to external MCP servers, extending your chatbots with tools and services beyond WordPress.

== Pro Features ==

* AI Forms
* Embeddings & Vector Databases
* Advanced Usage Control
* Realtime Audio Chatbot
* Priority Support

== Why AI Engine? ==

**Native to WordPress**
Built specifically for WordPress with seamless integration. No clunky interfaces, just native WordPress experience.

**Flexible & Powerful**
Support for multiple AI providers: OpenAI, Anthropic, Google, Hugging Face, and more. Use the models that work best for you.

**Developer Friendly**
Clean APIs, extensive hooks, and MCP support. Build custom AI features or entire SaaS applications on WordPress.

**Privacy First**
IP hashing, GDPR tools, secure file handling, and session-based tracking. You control your data.

**Constantly Evolving**
Weekly updates based on real user feedback. We listen, we improve.

== My Dream for AI ==

I am excited about AI, but I believe we need to use it with intention and clarity. Social media showed us how powerful tools can reshape our lives in ways we never expected, sometimes for the better, sometimes not. I want to avoid repeating those mistakes. AI should help us remove the meaningless, tedious work or enhance the work we enjoy. Modern tools should give us more time for what truly matters: spending beautiful moments with the people we love! 💕

== Installation ==

1. Upload `ai-engine` to `/wp-content/plugins/`
2. Activate through the 'Plugins' menu
3. Get an API key from OpenAI (or your preferred AI provider)
4. Add your API key in Settings (Meow Apps > AI Engine)
5. Start creating! 🚀

== Disclaimer ==

AI Engine is a plugin that helps you to connect your websites to AI services. You need your own API keys and must follow the rules set by the AI service you choose. For OpenAI, check their [Terms of Service](https://openai.com/terms/) and [Privacy Policy](https://openai.com/privacy/). It is also important to check your usage on the [OpenAI website](https://platform.openai.com/usage) for accurate information. Please do so with other services as well.

The developer of AI Engine and related parties are not responsible for any issues or losses caused by using the plugin or AI-generated content. You should talk to a legal expert and follow the laws and regulations of your country. AI Engine does only store data on your own server, and it is your responsibility to keep it safe. AI Engine's full disclaimer is [here](https://meowapps.com/ai-engine/disclaimer/).

== Compatibility ==

Please be aware that there may be conflicts with certain caching or performance plugins, such as SiteGround Optimizer and Ninja Firewall. To prevent any issues, ensure that AI Engine is excluded from these plugins.

== Frequently Asked Questions ==

= Why am I getting "Error 429: You exceeded your current quota"? =

This error comes from OpenAI's API, not AI Engine. Set up billing limits in your [OpenAI account](https://platform.openai.com/account/billing). Caching plugins can sometimes store error responses, so [clear your caches](https://ai.thehiddendocs.com/common-issues/exceeded-current-quota/) too.

= Who is AI Engine for, and how do I manage usage limits? =

AI Engine can be used by site owners, administrators, and visitors via chat widgets. To set query limits and prevent unlimited model runs, follow the [Managing Limits guide](https://ai.thehiddendocs.com/limits/).

= Does the chatbot support my language? =

AI models support many languages, but quality varies. There's no definitive list since models are constantly updated. [Test your language](https://ai.thehiddendocs.com/faq/does-it-support-my-language) in the AI Playground.

= How does MCP work, and what can I do with it? =

MCP (Model Context Protocol) exposes WordPress tools to AI agents. [Learn how to enable the SSE endpoint](https://ai.thehiddendocs.com/mcp/), choose which tools to expose, and secure them. You can manage posts, comments, users, media, and more.

= Can I restrict the chatbot to answer only from my site content? =

You can't completely block the model's built-in knowledge, but you can [use smart prompts and embeddings](https://ai.thehiddendocs.com/restrict-chatbot-topics/) to steer conversations toward your content.

= The chatbot doesn't appear or looks odd on my site =

Check the [Common Issues guide](https://ai.thehiddendocs.com/common-issues/) for solutions to REST API problems, caching conflicts, nonce errors, and layout glitches.

= Where can I learn the basics and troubleshoot problems? =

Start with the [Basics guide](https://ai.thehiddendocs.com/basics/) for installation and key concepts. For specific issues, check [Common Issues](https://ai.thehiddendocs.com/common-issues/).

= How do I report security issues? =

Report security vulnerabilities through the [Patchstack Vulnerability Disclosure Program](https://patchstack.com/database/vdp/9e5fbbbc-964a-4204-8bc0-198f21284efd).

== Changelog ==

= 3.3.1 (2026/01/04) =
* Update: Removed unused files and code to reduce clutter and improve performance.
* Info: Wishing you a Happy New Year 2026 ☀️🎉 No doubt this year will be full of surprises again, let’s continue riding the AI wave together! 😊

= 3.3.0 (2025/12/29) =
* Add: Added title filter to the Embeddings table.
* Add: Added filter to all model dropdowns.  
* Add: Enabled custom placeholder support and model-aware credit customization via new and updated filters for developers.  
* Add: Introduced prompt caching for Anthropic and a free-text dimension input for non-OpenAI embeddings.  
* Add: Added dimension mismatch warnings for Pinecone and Qdrant to help diagnose configuration issues.  
* Add: Included "speech_recognition" support in the embed.js system.
* Fix: Resolved multiple embedding issues, including OpenRouter parameter compatibility, Pinecone Serverless URLs, and vector store file uploads.  
* Fix: Improved compatibility with multilingual plugins, placeholder processing, and post content handling through dedicated filters.  
* Update: Performed an end-of-year cleanup by removing expired database migrations, deprecating outdated Claude 3 Opus models, and tidying up legacy debug and commented code.

= 3.2.9 (2025/12/17) =
* Add: Added support for the new gpt-image-1.5 model, works quite well! 😊  
* Fix: Restored reliable image editing (added missing file attachment handling, separating the edit mode prompt from templates, and preventing double dots in generated filenames).  
* Fix: Corrected Mistral model filtering so available models now appear and work as expected.  
* Fix: Resolved a UI crash when selecting OpenRouter providers that use non-standard model data.

= 3.2.8 (2025/12/12) =
* Add: Support for GPT-5.2 models (including gpt-5.2, gpt-5.2-chat-latest, and gpt-5.2-pro).
* Add: Support for placeholders in chatbot instructions.
* Add: MWAI_SSL_VERIFY constant so you can override SSL verification.
* Add: Files Manager in Dev Tools (+ improved file cleanup, locally and remotely at OpenAI and Anthropic).
* Update: Increased the maximum embeddings results limit from 100 to 1000.
* Update: Simplified file “purpose” options to just “analysis” or “generated” for clearer file handling.
* Update: Enhanced the Embeddings Query Mode and Dev Tools.
* Fix: Resolved a UI crash when selecting OpenRouter or other environments with non-standard models.
* Fix: Chroma integration now auto-creates the database and collection when needed.
* Fix: Prevented a rare crash in the Discussions tab.
* Fix: Clarified and improved error messages.

= 3.2.7 (2025/12/02) =
* Add: Support for OpenRouter embedding models.
* Update: Friendlier onboarding.  
* Update: Improve default environments with better validation.
* Update: Clearer warnings for misconfigured setups.
* Update: Enhanced the default CSS for Custom Theme.
* Fix: A few issues with Qdrant.

= 3.2.6 (2025/11/29) =
* Fix: Corrected the expected embedding model display for Qdrant and Pinecone.
* Fix: Corrected spacing between uploaded files/images and chatbot messages.
* Fix: Improved file handling in the Responses API to safely check file types.
* Fix: Resolved issues with mwai_forms_submit_params.
* Update: Refined the Discussions tab.
* Update: Added the --mwai-iconSize CSS variable to make the icon size adjustable.

= 3.2.5 (2025/11/26) =
* Update: Redesign the Knowledge settings section.
* Fix: Prevent DOM elements from being selected behind the chatbot while dragging it.
* Fix: Ensure Qdrant and Pinecone correctly use their intended embedding environment.
* 🎵 Discuss with others about Ai Engine on [the Discord](https://discord.gg/bHDGh38).
* 🌴 Keep us motivated with [a little review here](https://wordpress.org/support/plugin/ai-engine/reviews/). Thank you!
* 🥰 If you want to help us, check our [Patreon](https://www.patreon.com/meowapps). Thank you!
* 🚀 [Click here](https://trello.com/b/8U9SdiMy/ai-engine-feature-requests) to vote for the features you want the most.

= 3.2.4 (2025/11/23) =
* Add: Introduced a Mime Types selector (for Upload Files in Chatbots).
* Update: Added a new PHP API section and defined the REST API section. AI Engine is extremely easy to use with workflow automation tools like n8n, Make, Zapier, etc, so try it out! ✨
* Update: Renamed the "Context" section to "Knowledge & Context" and "Tools" to "Tools & Capabilities".
* Update: Better links to tutorials and documentation.
* Fix: Corrected the display of model names in Query Logs (such as GPT-4.1 and GPT-5.1).

= 3.2.3 (2025/11/18) =
* Add: Added support for the new gpt-5.1 model and included a 'none' option for reasoning effort settings.
* Add: Support for Chroma Cloud embeddings with the Qwen3 model.
* Fix: Enhanced error detection for Chroma responses.  
* Fix: Improved accuracy of audio transcription in AI Forms.  
* Fix: HTML Blocks are now in the scrollable conversation.
* Fix: Corrected MinScore of 0 to be recognized as a valid score.
* Fix: Fixed bulk sync process to correctly include vectors with model or env mismatches.
* Fix: Realtime transcript is now scrollable.
* Fix: Resolved the Embeddings Sync task to run properly with admin rights.
* Fix: Fixed undefined array key warnings in finetunes handling.
* Update: Removed deprecated fields from the embeddings section in AI Forms.
* Update: Minor enhancements in the UI.

= 3.2.1 (2025/11/11) =
* Add: IP validation for image uploads/downloads to prevent SSRF. 
* Add: Security measures to prevent PHAR deserialization.
* Add: Custom Theme CSS for Cross-Site .  
* Add: New 'Region' field for Azure (Realtime API needs this).
* Add: New filters (mwai_ai_embeddings_query and mwai_ai_feedback_query).  
* Add: Filter to allow customization of the embeddings rewrite prompt.
* Update: MeowCommon is now MeowKit.
* Update: Optimized the "Push All" feature for embeddings (now much, much faster).
* Fix: Corrected prompt mode to utilize the selected environment.
* Fix: Correct language detection in suggestions.  
* Fix: Ensure tasks return success even when handlers are missing. 
* Fix: Resolved issues with the embeddings sync task.  
* Fix: Got rid of a few warnings.

= 3.1.6 (2025/10/24) =
* Fix: Resolved MCP SSE worker exhaustion issue by handling agent cancellation signals.
* Add: Added Claude Haiku 4.5.
* Update: Enhanced the Import Embeddings task.
* Fix: Corrected the handling of implicitly nullable parameters.
* Fix: The Cleanup Files task now accurately deletes files based on their expiration dates.
* Fix: Minor bug fixes and improvements.

= 3.1.4 (2025/10/19) =
* Add: New MCP tool (wp_get_post_snapshot) to optimize data retrieval for complex post types.
* Fix: Security hardening for REST API endpoints to prevent unauthorized access.
* Fix: Avoid malformed UTF-8 issues.

= 3.1.3 (2025/10/15) =
* Add: Support for MCP with ChatGPT: https://meowapps.com/chatgpt-wordpress-mcp/.
* Update: Made the Public API easier to understand and to test.
* Update: Enhanced MCP and REST API sections.
* Update: Optimized the embeddings Push All/Sync process (much, much faster).

= 3.1.2 (2025/10/10) =
* Add: Realtime Hold-to-Talk feature now includes a Replay button.
* Add: Support for Azure OpenAI Realtime.
* Add: Resolutions and pricing for Google models.
* Add: GPT-5 Pro, GPT Realtime Mini, Sora 2, Gemini Images.
* Add: Multi-file support for chatbots and forms, both on the UI-side and the models-side.
* Update: Embeddings Sync has been migrated to the Tasks System.
* Update: Updated Anthropic and Gemini models.
* Fix: Image and video pricing.
* Fix: Hotfix applied to address missing category column in tasks DB.
* Fix: Realtime API calling now parameterless functions correctly.
* Fix: Fixed TypeError in embeddings list.
* Fix: Improved safety with SSRF protection for image downloads.
* Fix: Resolved various UI/UX issues to improve user experience.

= 3.1.1 (2025/09/30) =
* Add: Integrated Mistral AI into the plugin.
* Fix: Resolved an undefined array key "type" warning in Chroma.
* Fix: Corrected a database column name error in the task cleanup query.
* Fix: Fixed a layout issue in the Gutenberg editor.
* Fix: Resolved a crash in template creation when a user cancels the name prompt.
* Update: Optimized task refresh logic.
* Update: Included "reply" as an argument in mwai_ai_feedback.
* Update: Improved Google models retrieval logic.
* Update: Removed debugging logs, empty code blocks, etc.

= 3.1.0 (2025/09/17) =
* Add: New 'Hold to Talk' mode for Realtime chatbot.  
* Add: Tasks Manager (task scheduling, multi-step tasks, progress tracking, retry logic, etc).
* Fix: Resolved issues with Cross-Side to support renamed plugin folders.  
* Fix: Hotfix to ensure proper removal of all database tables during uninstall.  
* Fix: Corrected cross-origin CORS headers not being sent for allowed domains.

= 3.0.9 (2025/09/10) =
* Update: Improved the UI of the Forms Editor.  
* Update: Redesigned the PDF Import feature for a more streamlined workflow.  
* Update: Enhanced Embeddings UI with sortable titles, a smarter Sync button, and title preservation.
* Update: Enhance many parts of the UI, UX, better explanations, and more.
* Fix: Corrected PDF import chunking.
* Fix: Resolved PDF Import to correctly utilize custom titles.
* Fix: Improved PDF Import process to use Admin API instead of Public API.
* Fix: Addressed cache issues with lazy-loaded chunks by adding dynamic versioning.
* Fix: Cross-Site feature blocking same-origin requests.  
* Fix: Streaming issue where empty strings caused [Object] to appear.  
* Fix: Pinecone metadata error by defaulting the 'type' field to 'manual'.
* Fix: Resolved issues with bulk processes.

= 3.0.6 (2025/08/29) =
* Add: Image Upload for Realtime Chatbot.
* Add: New 'gpt-realtime' model.
* Add: Prompt Mode for chatbots to support OpenAI's new Prompts feature with prompt IDs.
* Update: Redesigned the Embeddings user interface with improved mode selection, icons, and standardized buttons.
* Update: Redesigned the Template component UI, cleaner layout, and icon-only buttons.
* Fix: Hotfix for orphan embeddings being created when editing from AI Search mode.
* Fix: Missing list styles in chatbot themes.

= 3.0.4 (2025/08/23) =
* Add: Support for Responses API with Azure OpenAI.
* Add: Download button for generated images in chatbot.
* Update: Better color picker with alpha support.
* Update: Many subtle UI improvements.
* Fix: Fixed Site Editor compatibility.
* Fix: Hotfix for center positioning of popup chatbots.
* Fix: Resolved JavaScript errors in Content Generator, Images Generator, and Playground.

= 3.0.2 (2025/08/21) =
* Update: Default token limits increased to 4096 and context length to 16384, with improved token info display.
* Add: Forms Editor for creating shortcodes, compatible with Classic Editor, Elementor, and more.
* Update: Enhanced the Timeless Theme with subtle visual improvements.
* Update: Added Slide and Fade animation effects with improved timing.
* Update: More refined window animations and timing synchronization.
* Fix: Support for 'message' type shortcuts in chatbots to enable simpler message delivery.
* Fix: Hotfix for header dragging issue on OSX in admin preview to prevent positioning problems.
* Fix: Resolved outdated URL issues.
* Fix: Center feature bug in Themes.
* Fix: Numerous minor CSS issues for a cleaner appearance.

= 3.0.1 (2025/08/17) =
* Add: Support for Code Interpreter tool in OpenAI chatbots.
* Update: Enhancements to the themes.
* Update: Window Animation now supports Zoom, Slide, and Fade (select in UI, or via CSS classes `mwai-animation-zoom`, `mwai-animation-slide`, `mwai-animation-fade`).
* Fix: Fixed Magic CSS Generator.
* Fix: Resolved missing parameter in Qdrant.

= 3.0.0 (2025/08/13) =
* Add: Brand new Terminal mode with SF Mono font, zoom animations, improved cursor behavior, fullscreen support, and more.
* Add: Custom CSS section for all themes for easy styling tweaks.
* Add: New clean square theme template for a fresh look.
* Update: Enhanced Discussions module and all themes with cleaner layouts, better gradients, and new styling options (border color, font family, etc.).
* Update: Popup chatbots now have smooth zoom animations, mobile-specific fixes, floating close button, and better trigger positioning.
* Update: UI Builder now disables Container and Header options when Popup is not enabled.
* Fix: Preserved HTML attributes in the "No Credits" message for proper styling.
* Fix: Corrected shortcode ID generation by ignoring system/visual-only parameters.
* Fix: Improved footer rendering, tools, alignment, and empty footer handling.
* Fix: Adjusted GPT-5 model usage calculations to handle dated variations correctly, fixed reasoning payload handling, and ensured JavaScript in HTML Blocks API executes properly.
* Fix: Fixed drag-and-drop file upload visual feedback for accepted/rejected states.

= 2.9.9 (2025/08/07) =
* Add: Support for GPT-5 model with reasoning and verbosity parameters.  
* Add: Windows compatibility support for MCP script. 
* Add: Support for MCP Servers in AI Forms.  
* Add: Cross-Site feature enabling chatbots to be embedded on external websites. 
* Add: Modular UI Builder with customizable containers, headers, and footers, including MacOS-style components.
* Add: Chatbot window width controls, center positioning option, and auto-open delay for better UX.  
* Add: Center (centerOpen) option in popup settings for centered chatbot windows.  
* Fix: Hotfix for drag-and-drop file handling error. 
* Fix: Resolved minor bugs and tiny enhancements.

= 2.9.8 (2025/08/01) =
* Add: Support for Chroma (another Vector DB) has been introduced for both Cloud and self-hosted instances.  
* Add: Multi-Upload feature has been added to chatbots for easier file management (currently only for developers, will be released to all users soon).
* Fix: Hotfix for discussion REST routes being accessible when the discussions module was disabled.
* Fix: Prevented pdf.worker.min.js from being accidentally deleted during production builds.
* Fix: Resolved PHP errors caused by duplicate property declarations and improved type safety for returned_price.
* Fix: Various other fixes and improvements throughout AI Engine.

= 2.9.6 (2025/07/29) =
* Fix: Addressed environment validation issues in Realtime chatbot to ensure reliable operation.  
* Fix: Solved GDPR consent issues in popup modal chatbots sharing the same botId.
* Add: clearCookies() in MwaiAPI.
* Update: Enhanced IP address display by truncating hashed IPs for privacy. 
* Fix: Updated audio transcription to support local file paths and refined the test suite for better reliability.  
* Fix: Secured file listing and deletion endpoints by adding user ownership checks and session-based tracking for guest users.  
* Fix: Prevented cron_discussions from running as a guest and hitting usage limits.
* Fix: Ensured image uploads are properly saved to discussions. 
* Fix: Made Event Logs operate independently of the Client Debug.
* Fix: Resolved query debug logs to only display when the Queries Debug setting is enabled.

= 2.9.5 (2025/07/22) =
* Update: Changed the AI Form Container block to output HTML directly instead of nesting shortcodes. That enhances AI Forms compatibility.
* Fix: Resolved a security issue related to SSRF by validating URL schemes in audio transcription and sanitizing REST API parameters to prevent API key misuse.  
* Fix: Corrected a critical security vulnerability that allowed unauthorized file uploads by adding strict file type validation to prevent PHP execution.  
* Implemented IP address hashing when Privacy First mode is active to enhance user privacy without disrupting discussions.

= 2.9.4 (2025/07/19) =
* Update: Improved information messages related to vector stores.  
* Fix: Centralized fallback logic in simpleFastTextQuery now automatically uses the default model to prevent silent failures.  
* Fix: Resolved fatal error when OpenAI Vector Store was set as default without a store ID. 
* Fix: Assistant environment detection now automatically identifies the correct environment when using assistants from non-default setups.  
* Fix: Corrected undefined method error related to logging.
* Update: Display errors as part of the conversation with options to copy, delete, or retry.

= 2.9.3 (2025/07/17) =
* Add: New Database Optimization feature in Dev Tools to improve plugin speed by adding indexes and removing old logs and discussions.
* Add: Better errors when encountering issues with OpenAI Responses API, Vector Store, or multiple functions.
* Add: simpleFileUpload feature to the Simple API for easier file handling.
* Add: OpenAI Vector Store as a new embeddings environment type for seamless integration with the file_search tool.
* Fix: Corrected the embeddings API to ensure proper vector creation and fixed related issues.
* Fix: Refined logging system and removed debug logs for cleaner operation.
* Fix: Replaced hardcoded model list with dynamic API capability detection.

= 2.9.2 (2025/07/11) =
* Add: Google embeddings are now live—only relevant environments show up, and we’ve built in safeguards against dimension mismatches.
* Add: A handy metadata bar in Discussions shows start date, last update, and message count. Plus, you can tweak its look via settings or our new PHP filters.
* Update: Embeddings sync now pops up a sleek NekoModal (goodbye alerts!), with clear stats on what’s updated, added, up-to-date, or errored—and even backend action logs.
* Update: API error messages got friendlier and more helpful.
* Update: Tables everywhere got a makeover—cleaner layouts, raw model names, better spacing, and clearer dimensions.
* Fix: Cron jobs no longer crash when no default environment or model is set.
* Fix: Chatbot module warnings when params or chatId were missing have been squashed with extra validation.
* Fix: System-logs no longer throw “undefined ‘sort’ key” warnings.
* Fix: Embeddings sync now clears the WP post cache so content changes are always detected, logs checksums for debugging, and adds a read-only Env ID field.
* Fix: Model/dimension mismatches are only checked if you’ve opted in, and the active Env ID is now visible in the UI.
* Fix: Custom chatbots keep their own embeddings environment instead of inheriting the default.
* Fix: Google model names are deduped and cleaned up (suffixes now in parentheses), with the newest versions listed first.

= 2.9.1 (2025/07/08) =
* Fix: Corrected guest user authentication by fixing the strpos check in session validation and making the start_session endpoint publicly accessible for proper guest login support.
* Add: Introduced options for Embeddings Search supporting multiple search methods.
* Add: New simpleFastTextQuery API endpoint.
* Update: Optimized vector search queries to accurately handle exclusion terms.

= 2.9.0 (2025/07/07) =
* Add: Persisted templates in Content Generator, Images Generator, and Playground.
* Update: Improved clarity in tables and selects.
* Fix: Limited PHP session starts to AI Engine's REST endpoints and added session status checks.
* Fix: Improved error handling for dynamic function additions via mwai_ai_query filter and ensured proper JSON encoding for mwai_ai_feedback objects in Chat Completions API.
* Fix: Enhanced CSV/JSON import error handling with detailed validation, specific error messages, and helpful examples in a modal dialog.
* Fix: Corrected guest user display in Discussions and Insights tables.

= 2.8.9 (2025/07/05) =
* Fix: Pinecone vector listing now correctly handles variable index dimensions by generating matching zero vectors instead of using a hardcoded size.
* Fix: Pinecone index name extraction has been improved to accurately process hyphenated index names, and a dimension mismatch indicator has been added next to the AI Environment title in embedding settings.
* Add: simpleTranscribeAudio method now provides a consistent API for audio transcription using the default AI audio settings.
* Fix: functions_list now exclusively retrieves snippets of the "function" type from Code Engine to improve accuracy.

= 2.8.8 (2025/07/04) =
* Add: Customizable Languages section in Settings > Others for easier language management.  
* Add: Query tracking in usage statistics with accuracy indicators for token counts and pricing sources.  
* Fix: Code Engine now correctly uses function names instead of snippet names for better clarity.  
* Fix: Resolved PHP warning when syncing vectors caused by missing ai_embeddings_dimensions key.  
* Fix: Fixed UI errors related to embedding model selectors, including conditional display, dimension validation, and UI improvements.

= 2.8.7 (2025/07/02) =
* Add: Smarter token and nonce management for longer, more reliable sessions.
* Fix: Hotfix resolves issues with event logs display and enables proper event logging under Streaming mode for realtime chatbots.
* Add: Quick Test buttons for AI and embedding environments to verify API connections.
* Update: Default embeddings set to text-embedding-3-small.
* Fix: Prevents duplicate Media Library entries and stops unwanted auto-saving in the Images Generator.
* Add: Web Search support for Google Gemini models.
* Fix: XSS vulnerability hotfix in chatbot shortcode.
* Fix: Hotfix for unquoted userId in SQL queries to prevent database errors.
* Update: Enhanced usage metrics, cleaner model names, and more.
* Fix: Improved multiple function call handling and resolved reset issues for compatibility with OpenAI, Claude, and Google.
* Add: Initial limits for Realtime (still a bit tricky, but progressing!).
* Update: Improved PDF import with different chunking modes.
* Update: Improved the default CSS theme.
* Update: General refactoring with many small improvements and fixes.
* Update: Better debugging and error handling all around.

= 2.8.4 (2025/06/18) =
* Add: History Strategy for Responses API chatbots. This allows chatbots to maintain a history of interactions, including images being modified or generated.
* Add: AI Want support for more blocks, like tables, lists, headers, etc.
* Add: Tools support (web_search, image_generation) with the Responses API.
* Add: Edit Mode for Images, with mask support.
* Update: Streamlined MCP logging, improved documentation.
* Fix: Duplicate Media Library entries.
* Fix: PDF worker URL (sorry about that, guys).
* Fix: Vision support for Responses API.
* Fix: Hotfix for security issues related to MCP.
* Info: More fixes and improvements which are too numerous to list here. We will have another round of improvements coming within 3-4 days. Don't hesitate to leave a review and mention something you would like to see improved or fixed.

= 2.8.3 (2025/06/07) =
* Add: Support for the new OpenAI Responses API (function calling, vision, feedback, MCP) – enable it in Settings when you’re ready.
Add: Vector-Aware Search – override the default WordPress search with either AI-generated keywords or Embeddings for sharper results.
* Add: PDF Import – upload a PDF, tweak the chunk size, and auto-create embeddings in one flow.
* Add: Embeddings stream event that shows when external context is pulled in.
* Add: Stream-events viewer now appears under each chatbot whenever Client Debug is on (and streaming is enabled).
* Add: Claude MCP support, MCP-server picker in Chatbots, per-category Show Details buttons, and copy-to-clipboard endpoint fields; you can even create or edit plugins via MCP.
* Add: “Does Not Contain” operator for AI Conditional Blocks.
* Add: Extensible context menus in Discussions through new MwaiAPI filters.
* Add: dev-notes.md packed with tips for developers who want to extend AI Engine.
* Update: Replaced NekoCollapsableCategories with NekoAccordions and refreshed the whole Settings navigation.
* Update: Streaming debugger renamed to ChatbotEvents, unified wording, and clearer status messages.
* Fix: Function-execution mapping, duplicate result events, and double fires in React.
* Fix: Error and input states are now fully isolated per chatbot instance.
* Fix: Clear button and reset logic in the event viewer.
* Security: Patched a potential MCP injection vector.
* Misc: Many small optimisations, typo/translation fixes, and cleaner source comments.

= 2.8.2 (2025/05/23) =
* Add: New Claude 4 models for enhanced AI capabilities.
* Update: Settings reorganized for improved usability, and Statistics and Embeddings renamed to Insights and Knowledge for better clarity.
* Fix: Hotfix for streaming issues and added a filter to customize the discussions refresh interval.
* Update: More consistent and user-friendly UI in Content and Image Generators, including a clean modal for Image Generator and improved custom chatbot block.
* Add: Multi-condition support for AI Forms with new operators, and better handling of required fields within conditional containers.

= 2.8.1 (2025/05/03) =
* Fix: Resolve issue with DALL-E model usage on Azure platforms.
* Add: Allow API Key override through query parameter for OpenRouter integration.
* Add: Filter `mwai_discussions_refresh_interval` to control how often the discussions list refreshes.

= 2.7.9 (2025/04/30) =
* Add: Support for gpt-image (the latest OpenAI model).
* Add: Support for MCP (Model Context Protocol). Check the [tutorial](https://meowapps.com/claude-wordpress-mcp/)! It's awesome, but remember it's a beta feature.
* Fix: Avoid a few warnings and notices.
* Fix: Compatibility with stateless WPs.
* Fix: Added Row Actions in Pages.
* Update: Accurate pricing is now always smoothly retrieved for OpenRouter, thanks to their new API.
* Update: Optimized the bundle size of the chatbot.

= 2.7.6 (2025/04/15) =
* Add: Added GPT 4.1 models, and set 4.1 Nano as the new default model.
* Add: Privacy First option to set the amount of personal data to the minimum.
* Add: Handle array properties for Function Calling.
* Add: Scope can now be modified for chatbots and forms.
* Add: Add a filter in the models dropdown if there are more than 16 models.
* Add: Accurate pricing with OpenRouter can be enabled by adding MWAI_OPENROUTER_ACCURATE_PRICING to your wp-config.php, and setting it to true. This will add 1-2 seconds to the response time.
* Update: Only define MWAI_TIMEOUT if it's not defined yet, that allows it to be overridden.
* Fix: An AI form without any inputs should be always valid.
* Fix: Give more info when an Pinecone upsert fails.
* Fix: Improvements for Google Gemini. Now works with Function Calling. Special thanks to Anaheim!
* Fix: Avoid a silent crash with Pinecone when a slash is added to the Server URL.
* Fix: Prevent Meow_MWAI_Query_Parameter to crash WordPress entirely.

= 2.7.5 (2025/03/12) =
* Add: Introduced support for Claude 3.7.
* Add: Updated pricing and added support for gpt-4.5-preview, o1-mini, and o3-mini.
* Fix: OpenAI Assistants (tools) can now be updated without overwriting existing settings.
* Fix: Prevented AI Forms from overriding HTML elements without a data-default-value attribute.
* Fix: Required fields in AI Forms are now strictly enforced, even if not mentioned in the prompt.
* Fix: Resolved issues with fields via selectors not being saved or re-applied on load.
* Update: Added additional checks to ensure the store is processed before attaching it to a thread in OpenAI Assistants.
* Update: Improved support for Assistants working with Forms and individual File Uploads, though OpenAI's Vector Store remains buggy.
* Fix: Addressed an issue with AI Forms and MIME types—OpenAI only supports images, but Anthropic handles PDFs well.
* Update: Replaced set_max_sentences with set_max_messages for better clarity.
* Update: Links in the chatbot now always open in a new tab for better user experience.
* Note: Function Calling is now expected to work, but Gemini remains unreliable.
* Remove: No more OpenAI Status, as they have discontinued their RSS feed.

= 2.7.4 (2025/01/26) =
* Add: Support for Perplexity models.
* Add: MwaiAPI works with AI Forms (ai.formReply filter, forms, getForm).
* Update: Azure API set to 2024-12-01 version.
* Update: Apply the tools and vision tags correctly on models from OpenRouter.
* Fix: Re-added the shortcode related to statistics.
* Fix: Fallback to default resolution if the model doesn't support the resolution.
* Info: New add-on for DeepSeek: https://meowapps.com/products/deepseek/.

= 2.7.3 (2025/01/16) =
* Add: Realtime is now supported in Discussions and Queries (costs are calculated based on the tokens returned by OpenAI).
* Update: Smarter way to handle the synchronization of embeddings. They are deleted if they have no content, and they only synchronize if it is needed.
* Update: OpenAI now uses max_completion_tokens instead of max_tokens.
* Fix: With AI Forms, the Select/Radio could show no option selected by default.
* Fix: o1 wasn't working properly with the Content Generator (the issue was related to Max Tokens).
* Add: In Content Generator, Max Tokens are now optional.
* Fix: Avoid the Chatbot Block to crash when switching to Custom.
* Add: A button to 'Run Tasks' in the 'Dev Tools'.

= 2.7.2 (2025/01/05) =
* Add: Realtime Audio Chatbot (Pro Version)! It works very well, including with function calling. Try it out! But be careful, those models are quite pricey. AI Engine doesn't handle the statistics yet (Queries / Discussions tabs).
* Add: New attribute 'className' for the Shortcuts API.
* Fix: Selectors in AI Forms now retrieve the content in divs correctly.
* Fix: The Chat Block in Custom Mode was not working properly.

= 2.6.9 (2025/01/01) =
* Info: Happy New Year to you all, AI bro's and sis'! 🎉
* Add: Support for o1 (if you have access to it).
* Update: Handle streaming with o1 (depending on the exact model).
* Info: o1 Preview and o1 Mini doesn't work with Instructions or Contexts (Embeddings, etc.). This is a limitation from OpenAI. AI Engine will handle this as soon as OpenAI allows it. However, it works with o1.
* Add: o1 support in the Usage section.
* Add: Option for the auto-titling feature for discussions.
* Add: Option to modify the Header Subtitle for the Timeless Theme ("Discuss with").
* Add: Option to Ignore Word Boundaries (= spaces!) in the Security section.
* Add: Three new JS functions for the Chatbot API: getBlocks, addBlock and removeBlockById.
* Add: New Upload Field in the AI Forms. Work with images, files, audios (one file per form for now).
* Add: New 'callback' type for the Shortcuts. It requires an 'onClick' function.
* Add: Added {CATEGORY}, {CATEGORIES}, {AUTHOR}, {PUBLISH_DATE} placeholders for embeddings' prompt.
* Add: Local Memory for the AI Forms (check the parameters of the Submit Block).
* Add: Reset Button for AI Forms.
* Update: The auto-titling feature for discussions is now more reliable.
* Update: HTML is allowed in the Instructions.
* Update: Better instructions in the Finetunes Data Editor.
* Update: Tiny enhancements on the Timeless Theme.
* Add: Button to Reset Usage (Dashboard tab).
* Fix: Issue related to initial HTML blocks (the GRDP block could reset all the blocks).
* Fix: The Discussions Auto-Refresh only works if the browser tab is active.
* Fix: Using chatId via the API was causing a crash.
* Fix: Enhanced the internal API around takeovers.
* Fix: Assistants were not behaving properly when a Function Call was not giving back the expected result.
* Fix: Context in the Queries (Statistics Module) is now available for Assistants.
* Fix: Handle RTL websites better.
* Fix: If the environment is Default, then Model is also Default (for Chatbots and AI Forms).
