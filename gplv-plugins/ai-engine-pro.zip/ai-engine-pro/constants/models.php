<?php

// Price as of June 2024: https://openai.com/api/pricing/

// TODO: After 2027-02 (OpenAI ends fine-tune job creation on 2027-01-06), drop the `finetune` key from every model entry below and remove 'finetune' from every model's `tags` array.

define( 'MWAI_OPENAI_MODELS', [
  /*
    GPT-6 Astra
    OpenAI's flagship, released 2026-09-03. Tool calling only works through the
    Responses API, which the 'responses' tag already forces for this model.
    https://developers.openai.com/api/docs/models/gpt-6-astra
    */
  [
    'model' => 'gpt-6-astra',
    'name' => 'GPT-6 Astra',
    'family' => 'gpt-6',
    'features' => ['completion'],
    'price' => [
      'in' => 10.00,
      'out' => 50.00,
      'cached' => 1.00,
    ],
    'type' => 'token',
    'unit' => 1 / 1000000,
    'maxCompletionTokens' => 128000,
    'maxContextualTokens' => 1050000,
    'finetune' => false,
    // No 'verbosity': unlike the GPT-5.6 line, the model page does not document it.
    // 'no-temperature': the API answers 400 "Unsupported parameter: 'temperature'" for this
    // model. The GPT-5 line is caught by a name check in the engines, which a gpt-6 id does
    // not match, so the tag is what stops us sending it (verified live 2026-09-05).
    'tags' => ['core', 'chat', 'vision', 'files', 'functions', 'json', 'responses', 'mcp', 'reasoning', 'no-temperature', 'latest'],
    'tools' => ['web_search', 'code_interpreter'],
    'params' => [
      // 'max' is new with this model; the effort dropdown reads this list.
      // No 'none': the API answers 400 "Unsupported value: 'none' is not supported"
      // for this model (verified live 2026-09-12), so the engine snaps it to 'low'.
      'reasoning' => ['low', 'medium', 'high', 'xhigh', 'max']
    ]
  ],
  /*
    GPT-5.6 Sol
    Frontier tier of the GPT-5.6 family; the bare gpt-5.6 alias points here.
    https://developers.openai.com/api/docs/models/gpt-5.6-sol
    */
  [
    'model' => 'gpt-5.6-sol',
    'name' => 'GPT-5.6 Sol',
    'family' => 'gpt-5',
    'features' => ['completion'],
    // Price cut by OpenAI on 2026-08-21 (was 5.00 / 30.00 / 0.50). Announced as
    // promotional "at least through 2026-11-21", so re-check it after that date.
    'price' => [
      'in' => 4.00,
      'out' => 20.00,
      'cached' => 0.40,
    ],
    'type' => 'token',
    'unit' => 1 / 1000000,
    'maxCompletionTokens' => 128000,
    'maxContextualTokens' => 1050000,
    'finetune' => false,
    'tags' => ['core', 'chat', 'vision', 'files', 'functions', 'json', 'responses', 'mcp', 'reasoning', 'verbosity', 'latest'],
    'tools' => ['web_search', 'image_generation', 'file_search', 'code_interpreter'],
    'params' => [
      'reasoning' => ['none', 'low', 'medium', 'high', 'xhigh'],
      'verbosity' => ['low', 'medium', 'high']
    ]
  ],
  /*
    GPT-5.6 Terra
    Balanced tier: strong intelligence at mid pricing.
    https://developers.openai.com/api/docs/models/gpt-5.6-terra
    */
  [
    'model' => 'gpt-5.6-terra',
    'name' => 'GPT-5.6 Terra',
    'family' => 'gpt-5',
    'features' => ['completion'],
    // Price cut by OpenAI on 2026-07-30 (was 2.50 / 15.00 / 0.25).
    'price' => [
      'in' => 2.00,
      'out' => 12.00,
      'cached' => 0.20,
    ],
    'type' => 'token',
    'unit' => 1 / 1000000,
    'maxCompletionTokens' => 128000,
    'maxContextualTokens' => 1050000,
    'finetune' => false,
    'tags' => ['core', 'chat', 'vision', 'files', 'functions', 'json', 'responses', 'mcp', 'reasoning', 'verbosity'],
    'tools' => ['web_search', 'image_generation', 'file_search', 'code_interpreter'],
    'params' => [
      'reasoning' => ['none', 'low', 'medium', 'high', 'xhigh'],
      'verbosity' => ['low', 'medium', 'high']
    ]
  ],
  /*
    GPT-5.6 Luna
    Efficient, high-volume tier of the GPT-5.6 family.
    https://developers.openai.com/api/docs/models/gpt-5.6-luna
    */
  [
    'model' => 'gpt-5.6-luna',
    'name' => 'GPT-5.6 Luna',
    'family' => 'gpt-5',
    'features' => ['completion'],
    // Price cut by OpenAI on 2026-07-30 (was 1.00 / 6.00 / 0.10).
    'price' => [
      'in' => 0.20,
      'out' => 1.20,
      'cached' => 0.02,
    ],
    'type' => 'token',
    'unit' => 1 / 1000000,
    'maxCompletionTokens' => 128000,
    'maxContextualTokens' => 1050000,
    'finetune' => false,
    'tags' => ['core', 'chat', 'vision', 'files', 'functions', 'json', 'responses', 'mcp', 'reasoning', 'verbosity'],
    'tools' => ['web_search', 'image_generation', 'file_search', 'code_interpreter'],
    'params' => [
      'reasoning' => ['none', 'low', 'medium', 'high', 'xhigh'],
      'verbosity' => ['low', 'medium', 'high']
    ]
  ],
  /*
    GPT-5.5
    Previous flagship: tool-heavy agents, grounded assistants, long-context retrieval
    https://developers.openai.com/api/docs/models/gpt-5.5
    */
  [
    'model' => 'gpt-5.5',
    'name' => 'GPT-5.5',
    'family' => 'gpt-5',
    'features' => ['completion'],
    'price' => [
      'in' => 5.00,
      'out' => 30.00,
      'cached' => 0.50,
    ],
    'type' => 'token',
    'unit' => 1 / 1000000,
    'maxCompletionTokens' => 128000,
    'maxContextualTokens' => 1050000,
    'finetune' => false,
    'tags' => ['core', 'chat', 'vision', 'files', 'functions', 'json', 'responses', 'mcp', 'reasoning', 'verbosity'],
    'tools' => ['web_search', 'image_generation', 'file_search', 'code_interpreter'],
    'params' => [
      'reasoning' => ['none', 'low', 'medium', 'high', 'xhigh'],
      'verbosity' => ['low', 'medium', 'high']
    ]
  ],
  /*
    GPT-5.4
    Our most capable model for professional work
    https://platform.openai.com/docs/models/gpt-5.4
    */
  [
    'model' => 'gpt-5.4',
    'name' => 'GPT-5.4',
    'family' => 'gpt-5',
    'features' => ['completion'],
    'price' => [
      'in' => 2.50,
      'out' => 15.00,
    ],
    'type' => 'token',
    'unit' => 1 / 1000000,
    'maxCompletionTokens' => 128000,
    'maxContextualTokens' => 1050000,
    'finetune' => false,
    'tags' => ['core', 'chat', 'vision', 'files', 'functions', 'json', 'responses', 'mcp', 'reasoning', 'verbosity'],
    'tools' => ['web_search', 'image_generation', 'file_search', 'code_interpreter'],
    'params' => [
      'reasoning' => ['none', 'low', 'medium', 'high', 'xhigh'],
      'verbosity' => ['low', 'medium', 'high']
    ]
  ],
  /*
    GPT-5.4 Pro
    Most advanced model with enhanced reasoning for complex tasks
    https://developers.openai.com/api/docs/models/gpt-5.4-pro
    */
  [
    'model' => 'gpt-5.4-pro',
    'name' => 'GPT-5.4 Pro',
    'family' => 'gpt-5',
    'features' => ['completion'],
    'price' => [
      'in' => 30.00,
      'out' => 180.00,
    ],
    'type' => 'token',
    'unit' => 1 / 1000000,
    'maxCompletionTokens' => 128000,
    'maxContextualTokens' => 1050000,
    'finetune' => false,
    'tags' => ['core', 'chat', 'vision', 'files', 'functions', 'responses', 'mcp', 'reasoning'],
    'tools' => ['web_search', 'image_generation', 'file_search'],
    'params' => [
      'reasoning' => ['medium', 'high', 'xhigh'],
    ]
  ],
  /*
    GPT-5.4 Mini
    Fast and cost-effective GPT-5.4 variant
    https://developers.openai.com/api/docs/models/gpt-5.4-mini
    */
  [
    'model' => 'gpt-5.4-mini',
    'name' => 'GPT-5.4 Mini',
    'family' => 'gpt-5',
    'features' => ['completion'],
    'price' => [
      'in' => 0.75,
      'out' => 4.50,
    ],
    'type' => 'token',
    'unit' => 1 / 1000000,
    'maxCompletionTokens' => 128000,
    'maxContextualTokens' => 400000,
    'finetune' => false,
    'tags' => ['core', 'chat', 'vision', 'files', 'functions', 'json', 'responses', 'mcp', 'reasoning', 'verbosity'],
    'tools' => ['web_search', 'image_generation', 'file_search', 'code_interpreter'],
    'params' => [
      'reasoning' => ['none', 'low', 'medium', 'high', 'xhigh'],
      'verbosity' => ['low', 'medium', 'high']
    ]
  ],
  /*
    GPT-5.4 Nano
    Ultra-fast and lightweight GPT-5.4 model
    https://developers.openai.com/api/docs/models/gpt-5.4-nano
    */
  [
    'model' => 'gpt-5.4-nano',
    'name' => 'GPT-5.4 Nano',
    'family' => 'gpt-5',
    'features' => ['completion'],
    'price' => [
      'in' => 0.20,
      'out' => 1.25,
    ],
    'type' => 'token',
    'unit' => 1 / 1000000,
    'maxCompletionTokens' => 128000,
    'maxContextualTokens' => 400000,
    'finetune' => false,
    'tags' => ['core', 'chat', 'vision', 'files', 'functions', 'json', 'responses', 'mcp', 'reasoning', 'verbosity'],
    'tools' => ['web_search', 'image_generation', 'file_search', 'code_interpreter'],
    'params' => [
      'reasoning' => ['none', 'low', 'medium', 'high', 'xhigh'],
      'verbosity' => ['low', 'medium', 'high']
    ]
  ],
  /*
    GPT-5.3 Chat
    GPT-5.3 model used in ChatGPT
    https://developers.openai.com/api/docs/models/gpt-5.3-chat-latest
    Shutdown: August 10, 2026.
    */
  [
    'model' => 'gpt-5.3-chat-latest',
    'name' => 'GPT-5.3 Chat',
    'family' => 'gpt-5',
    'features' => ['completion'],
    'price' => [
      'in' => 1.75,
      'out' => 14.00,
    ],
    'type' => 'token',
    'unit' => 1 / 1000000,
    'maxCompletionTokens' => 16384,
    'maxContextualTokens' => 128000,
    'finetune' => false,
    'tags' => ['core', 'chat', 'vision', 'files', 'functions', 'json', 'responses', 'mcp', 'deprecated'],
    'tools' => ['image_generation', 'code_interpreter']
  ],
  /*
    GPT-5.2
    The best model for coding and agentic tasks across industries
    https://platform.openai.com/docs/models/gpt-5.2
    */
  [
    'model' => 'gpt-5.2',
    'name' => 'GPT-5.2',
    'family' => 'gpt-5',
    'features' => ['completion'],
    'price' => [
      'in' => 1.75,
      'out' => 14.00,
    ],
    'type' => 'token',
    'unit' => 1 / 1000000,
    'maxCompletionTokens' => 128000,
    'maxContextualTokens' => 400000,
    'finetune' => false,
    'tags' => ['core', 'chat', 'vision', 'files', 'functions', 'json', 'responses', 'mcp', 'reasoning', 'verbosity'],
    'tools' => ['web_search', 'image_generation', 'file_search', 'code_interpreter'],
    'params' => [
      'reasoning' => ['none', 'low', 'medium', 'high', 'xhigh'],
      'verbosity' => ['low', 'medium', 'high']
    ]
  ],
  /*
    GPT-5.2 Chat
    GPT-5.2 model used in ChatGPT
    https://platform.openai.com/docs/models/gpt-5.2
    Shutdown: August 10, 2026.
    */
  [
    'model' => 'gpt-5.2-chat-latest',
    'name' => 'GPT-5.2 Chat',
    'family' => 'gpt-5',
    'features' => ['completion'],
    'price' => [
      'in' => 1.75,
      'out' => 14.00,
    ],
    'type' => 'token',
    'unit' => 1 / 1000000,
    'maxCompletionTokens' => 128000,
    'maxContextualTokens' => 400000,
    'finetune' => false,
    'tags' => ['core', 'chat', 'vision', 'files', 'responses', 'mcp', 'deprecated'],
    'tools' => ['web_search', 'file_search', 'code_interpreter']
  ],
  /*
    GPT-5.2 Pro
    Version of GPT-5.2 that produces smarter and more precise responses
    https://platform.openai.com/docs/models/gpt-5.2-pro
    */
  [
    'model' => 'gpt-5.2-pro',
    'name' => 'GPT-5.2 Pro',
    'family' => 'gpt-5',
    'features' => ['completion'],
    'price' => [
      'in' => 21.00,
      'out' => 168.00,
    ],
    'type' => 'token',
    'unit' => 1 / 1000000,
    'maxCompletionTokens' => 128000,
    'maxContextualTokens' => 400000,
    'finetune' => false,
    'tags' => ['core', 'chat', 'vision', 'files', 'functions', 'json', 'responses', 'mcp', 'reasoning', 'verbosity'],
    'tools' => ['web_search', 'image_generation', 'file_search', 'code_interpreter'],
    'params' => [
      'reasoning' => ['medium', 'high', 'xhigh'],
      'verbosity' => ['low', 'medium', 'high']
    ]
  ],
  /*
    GPT-5.1
    Demo model with enhanced capabilities
    https://platform.openai.com/docs/models/gpt-5.1
    */
  [
    'model' => 'gpt-5.1',
    'name' => 'GPT-5.1',
    'family' => 'gpt-5',
    'features' => ['completion'],
    'price' => [
      'in' => 1.25,
      'out' => 10.00,
    ],
    'type' => 'token',
    'unit' => 1 / 1000000,
    'maxCompletionTokens' => 128000,
    'maxContextualTokens' => 400000,
    'finetune' => false,
    'tags' => ['core', 'chat', 'vision', 'files', 'functions', 'json', 'responses', 'mcp', 'reasoning', 'verbosity'],
    'tools' => ['web_search', 'image_generation', 'file_search', 'code_interpreter'],
    'params' => [
      'reasoning' => ['none', 'minimal', 'low', 'medium', 'high'],
      'verbosity' => ['low', 'medium', 'high']
    ]
  ],
  /*
    GPT-5
    The best model for coding and agentic tasks across domains
    https://platform.openai.com/docs/models/gpt-5
    */
  [
    'model' => 'gpt-5',
    'name' => 'GPT-5',
    'family' => 'gpt-5',
    'features' => ['completion'],
    'price' => [
      'in' => 1.25,
      'out' => 10.00,
    ],
    'type' => 'token',
    'unit' => 1 / 1000000,
    'maxCompletionTokens' => 128000,
    'maxContextualTokens' => 400000,
    'finetune' => false,
    // Shutdown: December 10, 2026.
    'tags' => ['core', 'chat', 'vision', 'files', 'functions', 'json', 'responses', 'mcp', 'reasoning', 'verbosity', 'deprecated'],
    'tools' => ['web_search', 'image_generation', 'file_search', 'code_interpreter'],
    'params' => [
      'reasoning' => ['none', 'minimal', 'low', 'medium', 'high'],
      'verbosity' => ['low', 'medium', 'high']
    ]
  ],
  /*
    GPT-5 Mini
    Efficient and cost-effective GPT-5 variant
    https://platform.openai.com/docs/models/gpt-5-mini
    */
  [
    'model' => 'gpt-5-mini',
    'name' => 'GPT-5 Mini',
    'family' => 'gpt-5',
    'features' => ['completion'],
    'price' => [
      'in' => 0.25,
      'out' => 2.00,
    ],
    'type' => 'token',
    'unit' => 1 / 1000000,
    'maxCompletionTokens' => 128000,
    'maxContextualTokens' => 400000,
    'finetune' => false,
    // Shutdown: December 10, 2026.
    'tags' => ['core', 'chat', 'vision', 'files', 'functions', 'json', 'responses', 'mcp', 'reasoning', 'verbosity', 'deprecated'],
    'tools' => ['web_search', 'image_generation', 'file_search', 'code_interpreter'],
    'params' => [
      'reasoning' => ['none', 'minimal', 'low', 'medium', 'high'],
      'verbosity' => ['low', 'medium', 'high']
    ]
  ],
  /*
    GPT-5 Nano
    Ultra-fast and lightweight GPT-5 model
    https://platform.openai.com/docs/models/gpt-5-nano
    */
  [
    'model' => 'gpt-5-nano',
    'name' => 'GPT-5 Nano',
    'family' => 'gpt-5',
    'features' => ['completion'],
    'price' => [
      'in' => 0.05,
      'out' => 0.40,
    ],
    'type' => 'token',
    'unit' => 1 / 1000000,
    'maxCompletionTokens' => 128000,
    'maxContextualTokens' => 400000,
    'finetune' => false,
    // Shutdown: December 10, 2026.
    'tags' => ['core', 'chat', 'vision', 'files', 'functions', 'json', 'responses', 'mcp', 'reasoning', 'verbosity', 'deprecated'],
    'tools' => ['web_search', 'image_generation', 'file_search', 'code_interpreter'],
    'params' => [
      'reasoning' => ['none', 'minimal', 'low', 'medium', 'high'],
      'verbosity' => ['low', 'medium', 'high']
    ]
  ],
  /*
    GPT-5 Chat
    GPT-5 model used in ChatGPT
    https://platform.openai.com/docs/models/gpt-5
    */
  [
    'model' => 'gpt-5-chat-latest',
    'name' => 'GPT-5 Chat',
    'family' => 'gpt-5',
    'features' => ['completion'],
    'price' => [
      'in' => 1.25,
      'out' => 10.00,
    ],
    'type' => 'token',
    'unit' => 1 / 1000000,
    'maxCompletionTokens' => 16384,
    'maxContextualTokens' => 128000,
    'finetune' => false,
    // Shutdown: July 23, 2026.
    'tags' => ['core', 'chat', 'vision', 'files', 'responses', 'mcp', 'deprecated'],
    'tools' => ['web_search', 'file_search', 'code_interpreter'],
    'params' => [
      'verbosity' => ['low', 'medium', 'high']
    ]
  ],
  /*
    GPT-5 Pro
    Version of GPT-5 that produces smarter and more precise responses
    https://platform.openai.com/docs/models/gpt-5
    */
  [
    'model' => 'gpt-5-pro',
    'name' => 'GPT-5 Pro',
    'family' => 'gpt-5',
    'features' => ['completion'],
    'price' => [
      'in' => 15.00,
      'out' => 120.00,
    ],
    'type' => 'token',
    'unit' => 1 / 1000000,
    'maxCompletionTokens' => 272000,
    'maxContextualTokens' => 400000,
    'finetune' => false,
    // Shutdown: December 10, 2026.
    'tags' => ['core', 'chat', 'vision', 'files', 'functions', 'json', 'responses', 'mcp', 'reasoning', 'verbosity', 'deprecated'],
    'tools' => ['web_search', 'image_generation', 'file_search', 'code_interpreter'],
    'params' => [
      'reasoning' => ['none', 'minimal', 'low', 'medium', 'high'],
      'verbosity' => ['low', 'medium', 'high']
    ]
  ],
  /*
    GPT 4.1
    Flagship GPT model for complex tasks
    https://platform.openai.com/docs/models/gpt-4.1
    */
  [
    'model' => 'gpt-4.1',
    'name' => 'GPT-4.1',
    'family' => 'gpt-4',
    'features' => ['completion'],
    'price' => [
      'in' => 2.00,
      'out' => 8.00,
    ],
    'type' => 'token',
    'unit' => 1 / 1000000,
    'maxCompletionTokens' => 32768,
    'maxContextualTokens' => 1047576,
    'finetune' => false,
    'tags' => ['core', 'chat', 'vision', 'functions', 'json', 'finetune', 'responses', 'mcp', 'deprecated'],
    'tools' => ['web_search', 'image_generation', 'code_interpreter']
  ],
  /*
      GPT-4.1 mini
      Balanced for intelligence, speed, and cost
      https://platform.openai.com/docs/models/gpt-4.1-mini
      */
  [
    'model' => 'gpt-4.1-mini',
    'name' => 'GPT-4.1 Mini',
    'family' => 'gpt-4',
    'features' => ['completion'],
    'price' => [
      'in' => 0.40,
      'out' => 1.60,
    ],
    'type' => 'token',
    'unit' => 1 / 1000000,
    'maxCompletionTokens' => 32768,
    'maxContextualTokens' => 1047576,
    'finetune' => false,
    'tags' => ['core', 'chat', 'vision', 'functions', 'json', 'finetune', 'responses', 'mcp', 'deprecated'],
    'tools' => ['web_search', 'image_generation', 'code_interpreter']
  ],
  /*
        GPT-4.1 nano
        Fastest, most cost-effective GPT-4.1 model
        https://platform.openai.com/docs/models/gpt-4.1-nano
        */
  [
    'model' => 'gpt-4.1-nano',
    'name' => 'GPT-4.1 Nano',
    'family' => 'gpt-4',
    'features' => ['completion'],
    'price' => [
      'in' => 0.10,
      'out' => 0.40,
    ],
    'type' => 'token',
    'unit' => 1 / 1000000,
    'maxCompletionTokens' => 32768,
    'maxContextualTokens' => 1047576,
    'finetune' => false,
    // Shutdown: October 23, 2026.
    'tags' => ['core', 'chat', 'vision', 'functions', 'json', 'finetune', 'responses', 'mcp', 'deprecated'],
    'tools' => ['image_generation']
  ],
  /*
          GPT-4o
          Fast, intelligent, flexible GPT model
          https://platform.openai.com/docs/models/gpt-4o
          */
  [
    'model' => 'gpt-4o',
    'name' => 'GPT-4o',
    'family' => 'gpt-4',
    'features' => ['completion'],
    'price' => [
      'in' => 2.50,
      'out' => 10.00,
    ],
    'type' => 'token',
    'unit' => 1 / 1000000,
    'maxCompletionTokens' => 16384,
    'maxContextualTokens' => 128000,
    'finetune' => false,
    'tags' => ['core', 'chat', 'vision', 'functions', 'json', 'finetune', 'mcp', 'responses', 'deprecated'],
    'tools' => ['web_search', 'image_generation', 'code_interpreter']
  ],
  /*
            GPT-4o mini
            Fast, affordable small model for focused tasks
            https://platform.openai.com/docs/models/gpt-4o-mini
            */
  [
    'model' => 'gpt-4o-mini',
    'name' => 'GPT-4o Mini',
    'family' => 'gpt-4',
    'features' => ['completion'],
    'price' => [
      'in' => 0.15,
      'out' => 0.60,
    ],
    'type' => 'token',
    'unit' => 1 / 1000000,
    'maxCompletionTokens' => 16384,
    'maxContextualTokens' => 128000,
    'finetune' => [
      'in' => 0.15,
      'out' => 0.60,
      'train' => 3.00
    ],
    'tags' => ['core', 'chat', 'vision', 'functions', 'json', 'finetune', 'mcp', 'responses', 'deprecated'],
    'tools' => ['web_search', 'image_generation', 'code_interpreter']
  ],
  /*
            o3
            Advanced reasoning model
            https://platform.openai.com/docs/models/o3
            */
  [
    'model' => 'o3',
    'name' => 'o3',
    'family' => 'o3',
    'features' => ['completion'],
    // We were still on o3's launch-era pricing, so every o3 query was costed 7.5x too high.
    'price' => [
      'in' => 2.00,
      'out' => 8.00,
    ],
    'type' => 'token',
    'unit' => 1 / 1000000,
    'maxCompletionTokens' => 100000,
    'maxContextualTokens' => 200000,
    'tags' => ['core', 'chat', 'o1-model', 'reasoning', 'responses', 'mcp'],
    'tools' => ['web_search', 'image_generation', 'code_interpreter']
  ],
  /*
              o3-mini
              Fast, flexible, intelligent reasoning model
              https://platform.openai.com/docs/models/o3-mini
              */
  [
    'model' => 'o3-mini',
    'name' => 'o3 Mini',
    'family' => 'o3',
    'features' => ['completion'],
    'price' => [
      'in' => 1.10,
      'out' => 4.40,
    ],
    'type' => 'token',
    'unit' => 1 / 1000000,
    'maxCompletionTokens' => 100000,
    'maxContextualTokens' => 200000,
    // Shutdown: October 23, 2026.
    'tags' => ['core', 'chat', 'o1-model', 'reasoning', 'responses', 'mcp', 'deprecated'],
    'tools' => ['web_search', 'image_generation', 'code_interpreter']
  ],
  /*
                GPT Realtime 2
                Voice model with GPT-5-class reasoning, stronger instruction following, and multilingual support.
                https://platform.openai.com/docs/models/gpt-realtime-2
                */
  [
    'model' => 'gpt-realtime-2',
    'name' => 'GPT Realtime 2',
    'family' => 'realtime',
    'features' => ['core', 'realtime', 'functions'],
    'price' => [
      'text' => [
        'in' => 4.00,
        'cache' => 0.40,
        'out' => 16.00,
      ],
      'audio' => [
        'in' => 32.00,
        'cache' => 0.40,
        'out' => 64.00,
      ],
      'image' => [
        'in' => 5.00,
        'cache' => 0.50,
      ]
    ],
    'type' => 'token',
    'unit' => 1 / 1000000,
    'maxCompletionTokens' => 4096,
    'maxContextualTokens' => 128000,
    'finetune' => false,
    'tags' => ['core', 'realtime', 'functions', 'vision', 'mcp']
  ],
  /*
                GPT Realtime
                Production-ready speech-to-speech model with MCP, image input, and SIP support
                https://platform.openai.com/docs/models/gpt-realtime
                */
  [
    'model' => 'gpt-realtime',
    'name' => 'GPT Realtime',
    'family' => 'realtime',
    'features' => ['core', 'realtime', 'functions'],
    'price' => [
      'text' => [
        'in' => 4.00,
        'cache' => 0.40,
        'out' => 16.00,
      ],
      'audio' => [
        'in' => 32.00,
        'cache' => 0.40,
        'out' => 64.00,
      ],
      'image' => [
        'in' => 5.00,
        'cache' => 0.50,
      ]
    ],
    'type' => 'token',
    'unit' => 1 / 1000000,
    'maxCompletionTokens' => 4096,
    'maxContextualTokens' => 128000,
    'finetune' => false,
    'tags' => ['core', 'realtime', 'functions', 'vision', 'mcp']
  ],
  /*
                GPT Realtime Mini
                Cost-efficient version of GPT Realtime
                https://platform.openai.com/docs/models/gpt-realtime-mini
                */
  [
    'model' => 'gpt-realtime-mini',
    'name' => 'GPT Realtime Mini',
    'family' => 'realtime',
    'features' => ['core', 'realtime', 'functions'],
    'price' => [
      'text' => [
        'in' => 0.60,
        'cache' => 0.06,
        'out' => 2.40,
      ],
      'audio' => [
        'in' => 10.00,
        'cache' => 0.06,
        'out' => 20.00,
      ]
    ],
    'type' => 'token',
    'unit' => 1 / 1000000,
    'maxCompletionTokens' => 4096,
    'maxContextualTokens' => 32000,
    'finetune' => false,
    'tags' => ['core', 'realtime', 'functions', 'vision', 'deprecated']
  ],
  // TODO: gpt-realtime-translate and gpt-realtime-whisper are intentionally
  // not exposed yet. Both run on their own OpenAI endpoints
  // (/v1/realtime/translations/client_secrets and the realtime transcription
  // session) with a one-way streaming contract, no tools, no conversation,
  // and a different event prefix. They do not fit the chatbot session shape
  // in premium/realtime.php and would warrant their own "Live Translation"
  // and "Live Transcription" modes if a clear WordPress use case shows up.
  /*
      GPT Image
      OpenAI's image generation models (token-based pricing)
      https://platform.openai.com/docs/models/gpt-image-1
      */
  // GPT Image 2.5 (2026-09-10): Sunburst is tuned for editing precision, Flare for fast everyday
  // generation. Both add the xhigh and max quality levels and bill at GPT Image 2 token rates.
  [
    'model' => 'gpt-image-2.5-sunburst',
    'name' => 'GPT Image 2.5 Sunburst',
    'family' => 'gpt-image',
    'features' => ['text-to-image'],
    'resolutions' => [
      [
        'name' => '1024x1024',
        'label' => '1024x1024'
      ],
      [
        'name' => '1024x1536',
        'label' => '1024x1536'
      ],
      [
        'name' => '1536x1024',
        'label' => '1536x1024'
      ]
    ],
    'qualities' => [
      [ 'name' => 'auto',   'label' => 'Auto' ],
      [ 'name' => 'low',    'label' => 'Low' ],
      [ 'name' => 'medium', 'label' => 'Medium' ],
      [ 'name' => 'high',   'label' => 'High' ],
      [ 'name' => 'xhigh',  'label' => 'Extra High' ],
      [ 'name' => 'max',    'label' => 'Max' ]
    ],
    'type' => 'token',
    'mode' => 'image',
    'price' => [
      'in' => 8.00,
      'out' => 30.00,
      'cached' => 2.00
    ],
    'unit' => 1 / 1000000,
    'finetune' => false,
    'tags' => ['core', 'image', 'image-edit', 'responses']
  ],
  [
    'model' => 'gpt-image-2.5-flare',
    'name' => 'GPT Image 2.5 Flare',
    'family' => 'gpt-image',
    'features' => ['text-to-image'],
    'resolutions' => [
      [
        'name' => '1024x1024',
        'label' => '1024x1024'
      ],
      [
        'name' => '1024x1536',
        'label' => '1024x1536'
      ],
      [
        'name' => '1536x1024',
        'label' => '1536x1024'
      ]
    ],
    'qualities' => [
      [ 'name' => 'auto',   'label' => 'Auto' ],
      [ 'name' => 'low',    'label' => 'Low' ],
      [ 'name' => 'medium', 'label' => 'Medium' ],
      [ 'name' => 'high',   'label' => 'High' ],
      [ 'name' => 'xhigh',  'label' => 'Extra High' ],
      [ 'name' => 'max',    'label' => 'Max' ]
    ],
    'type' => 'token',
    'mode' => 'image',
    'price' => [
      'in' => 8.00,
      'out' => 30.00,
      'cached' => 2.00
    ],
    'unit' => 1 / 1000000,
    'finetune' => false,
    'tags' => ['core', 'image', 'image-edit', 'responses']
  ],
  [
    'model' => 'gpt-image-2',
    'name' => 'GPT Image 2',
    'family' => 'gpt-image',
    'features' => ['text-to-image'],
    'resolutions' => [
      [
        'name' => '1024x1024',
        'label' => '1024x1024'
      ],
      [
        'name' => '1024x1536',
        'label' => '1024x1536'
      ],
      [
        'name' => '1536x1024',
        'label' => '1536x1024'
      ]
    ],
    'qualities' => [
      [ 'name' => 'auto',   'label' => 'Auto' ],
      [ 'name' => 'low',    'label' => 'Low' ],
      [ 'name' => 'medium', 'label' => 'Medium' ],
      [ 'name' => 'high',   'label' => 'High' ]
    ],
    'type' => 'token',
    'mode' => 'image',
    'price' => [
      'in' => 8.00,
      'out' => 30.00,
      'cached' => 2.00
    ],
    'unit' => 1 / 1000000,
    'finetune' => false,
    'tags' => ['core', 'image', 'image-edit', 'responses']
  ],
  [
    'model' => 'gpt-image-1.5',
    'name' => 'GPT Image 1.5',
    'family' => 'gpt-image',
    'features' => ['text-to-image'],
    'resolutions' => [
      [
        'name' => '1024x1024',
        'label' => '1024x1024'
      ],
      [
        'name' => '1024x1536',
        'label' => '1024x1536'
      ],
      [
        'name' => '1536x1024',
        'label' => '1536x1024'
      ]
    ],
    'qualities' => [
      [ 'name' => 'auto',   'label' => 'Auto' ],
      [ 'name' => 'low',    'label' => 'Low' ],
      [ 'name' => 'medium', 'label' => 'Medium' ],
      [ 'name' => 'high',   'label' => 'High' ]
    ],
    'type' => 'token',
    'mode' => 'image',
    'price' => [
      'in' => 8.00,
      'out' => 32.00,
      'cached' => 2.00
    ],
    'unit' => 1 / 1000000,
    'finetune' => false,
    // Shutdown: December 1, 2026.
    'tags' => ['core', 'image', 'image-edit', 'responses', 'deprecated']
  ],
  [
    'model' => 'gpt-image-1',
    'name' => 'GPT Image 1',
    'family' => 'gpt-image',
    'features' => ['text-to-image'],
    'resolutions' => [
      [
        'name' => '1024x1024',
        'label' => '1024x1024'
      ],
      [
        'name' => '1024x1536',
        'label' => '1024x1536'
      ],
      [
        'name' => '1536x1024',
        'label' => '1536x1024'
      ]
    ],
    'qualities' => [
      [ 'name' => 'auto',   'label' => 'Auto' ],
      [ 'name' => 'low',    'label' => 'Low' ],
      [ 'name' => 'medium', 'label' => 'Medium' ],
      [ 'name' => 'high',   'label' => 'High' ]
    ],
    'type' => 'token',
    'mode' => 'image',
    'price' => [
      'in' => 10.00,
      'out' => 40.00,
      'cached' => 2.50
    ],
    'unit' => 1 / 1000000,
    'finetune' => false,
    // Shutdown: October 23, 2026.
    'tags' => ['core', 'image', 'image-edit', 'responses', 'deprecated']
  ],
  [
    'model' => 'gpt-image-1-mini',
    'name' => 'GPT Image 1 Mini',
    'family' => 'gpt-image',
    'features' => ['text-to-image'],
    'resolutions' => [
      [
        'name' => '1024x1024',
        'label' => '1024x1024'
      ],
      [
        'name' => '1024x1536',
        'label' => '1024x1536'
      ],
      [
        'name' => '1536x1024',
        'label' => '1536x1024'
      ]
    ],
    'qualities' => [
      [ 'name' => 'auto',   'label' => 'Auto' ],
      [ 'name' => 'low',    'label' => 'Low' ],
      [ 'name' => 'medium', 'label' => 'Medium' ],
      [ 'name' => 'high',   'label' => 'High' ]
    ],
    'type' => 'token',
    'mode' => 'image',
    'price' => [
      'in' => 2.50,
      'out' => 8.00,
      'cached' => 0.25
    ],
    'unit' => 1 / 1000000,
    'finetune' => false,
    // Shutdown: December 1, 2026.
    'tags' => ['core', 'image', 'image-edit', 'responses', 'deprecated']
  ],
  /*
    Sora 2
    Flagship video generation with synced audio
    https://platform.openai.com/docs/models/sora-2
    */
  [
    'model' => 'sora-2',
    'name' => 'Sora 2',
    'family' => 'sora',
    'features' => ['text-to-video'],
    'resolutions' => [
      [
        'name' => '720x1280',
        'label' => 'Portrait (720x1280)',
        'price' => 0.10
      ],
      [
        'name' => '1280x720',
        'label' => 'Landscape (1280x720)',
        'price' => 0.10
      ]
    ],
    'durations' => [ 4, 8, 12 ],
    'type' => 'video',
    'unit' => 'second',
    'finetune' => false,
    // Shutdown: September 24, 2026.
    'tags' => ['core', 'video', 'deprecated']
  ],
  [
    'model' => 'sora-2-pro',
    'name' => 'Sora 2 Pro',
    'family' => 'sora',
    'features' => ['text-to-video'],
    'resolutions' => [
      [
        'name' => '720x1280',
        'label' => 'Portrait (720x1280)',
        'price' => 0.30
      ],
      [
        'name' => '1280x720',
        'label' => 'Landscape (1280x720)',
        'price' => 0.30
      ],
      [
        'name' => '1024x1792',
        'label' => 'Portrait High (1024x1792)',
        'price' => 0.50
      ],
      [
        'name' => '1792x1024',
        'label' => 'Landscape High (1792x1024)',
        'price' => 0.50
      ]
    ],
    'durations' => [ 4, 8, 12 ],
    'type' => 'video',
    'unit' => 'second',
    'finetune' => false,
    // Shutdown: September 24, 2026.
    'tags' => ['core', 'video', 'deprecated']
  ],
  // Embedding models:
  // OpenAI v3 models support Matryoshka embeddings (MRL) allowing dimension truncation
  // while preserving semantic meaning. The dimensions array lists native + recommended sizes.
  // See: https://huggingface.co/blog/matryoshka
  [
    'model' => 'text-embedding-3-small',
    'name' => 'Embedding 3-Small',
    'family' => 'text-embedding',
    'features' => ['embedding'],
    'price' => 0.02,
    'type' => 'token',
    'unit' => 1 / 1000000,
    'finetune' => false,
    'dimensions' => 1536, // Native output dimension
    'tags' => ['core', 'embedding', 'matryoshka'],
  ],
  [
    'model' => 'text-embedding-3-large',
    'name' => 'Embedding 3-Large',
    'family' => 'text-embedding',
    'features' => ['embedding'],
    'price' => 0.13,
    'type' => 'token',
    'unit' => 1 / 1000000,
    'finetune' => false,
    'dimensions' => 3072, // Native output dimension
    'tags' => ['core', 'embedding', 'matryoshka'],
  ],
  // Ada-002 is a legacy model with fixed dimensions (no truncation support)
  [
    'model' => 'text-embedding-ada-002',
    'name' => 'Embedding Ada-002',
    'family' => 'text-embedding',
    'features' => ['embedding'],
    'price' => 0.10,
    'type' => 'token',
    'unit' => 1 / 1000000,
    'finetune' => false,
    'dimensions' => 1536, // Fixed dimension (no matryoshka support)
    'tags' => ['core', 'embedding'],
  ],
  // Audio Models:
  [
    'model' => 'gpt-transcribe',
    'name' => 'GPT Transcribe',
    'family' => 'whisper',
    'features' => ['speech-to-text'],
    'price' => 0.0045,
    'type' => 'second',
    'unit' => 1,
    'finetune' => false,
    'tags' => ['core', 'audio'],
  ],
  // whisper-1 and the gpt-4o-transcribe models were deprecated by OpenAI on 2026-08-26 and
  // shut down on 2027-02-26. Kept listed and tagged 'deprecated' so existing settings still
  // show what they point at. TODO: Remove after 2027-03-03.
  [
    'model' => 'gpt-4o-transcribe',
    'name' => 'GPT-4o Transcribe',
    'family' => 'whisper',
    'features' => ['speech-to-text'],
    'price' => 0.006,
    'type' => 'second',
    'unit' => 1,
    'finetune' => false,
    'tags' => ['core', 'audio', 'deprecated'],
  ],
  [
    'model' => 'gpt-4o-mini-transcribe',
    'name' => 'GPT-4o Mini Transcribe',
    'family' => 'whisper',
    'features' => ['speech-to-text'],
    'price' => 0.003,
    'type' => 'second',
    'unit' => 1,
    'finetune' => false,
    'tags' => ['core', 'audio', 'deprecated'],
  ],
  [
    'model' => 'whisper-1',
    'name' => 'Whisper',
    'family' => 'whisper',
    'features' => ['speech-to-text'],
    'price' => 0.006,
    'type' => 'second',
    'unit' => 1,
    'finetune' => false,
    'tags' => ['core', 'audio', 'deprecated'],
  ],
] );

define( 'MWAI_ANTHROPIC_MODELS', [
  [
    'model' => 'claude-fable-5-1',
    'name' => 'Claude Fable 5.1',
    'family' => 'claude-5',
    'features' => ['completion'],
    'price' => [
      'in' => 10.00,
      'out' => 50.00,
      // Cache reads are 0.025x the input price on Fable 5.1 (other Claude models use 0.1x).
      'cached' => 0.25,
    ],
    'type' => 'token',
    'unit' => 1 / 1000000,
    'maxCompletionTokens' => 128000,
    'maxContextualTokens' => 1000000,
    'finetune' => false,
    // Same surface as Fable 5 (always-on adaptive thinking, no temperature, no
    // prefill). New in 5.1: forced tool_choice (any/tool) returns a 400, and
    // replayed thinking blocks are bound to the conversation prefix. Our engine
    // never forces tool_choice and only replays blocks append-only within the
    // function-call loop, so no special handling is needed.
    'tags' => ['core', 'chat', 'vision', 'files', 'functions', 'reasoning', 'mcp', 'no-temperature', 'latest'],
    'tools' => ['code_interpreter', 'thinking', 'web_search']
  ],
  [
    'model' => 'claude-fable-5',
    'name' => 'Claude Fable 5',
    'family' => 'claude-5',
    'features' => ['completion'],
    'price' => [
      'in' => 10.00,
      'out' => 50.00,
    ],
    'type' => 'token',
    'unit' => 1 / 1000000,
    'maxCompletionTokens' => 128000,
    'maxContextualTokens' => 1000000,
    'finetune' => false,
    // Adaptive thinking is always on (no disabled mode, no manual budget, no
    // assistant prefill). Our engine never sends those, so no special handling.
    'tags' => ['core', 'chat', 'vision', 'files', 'functions', 'reasoning', 'mcp', 'no-temperature'],
    'tools' => ['code_interpreter', 'thinking', 'web_search']
  ],
  [
    'model' => 'claude-opus-5',
    'name' => 'Claude Opus 5',
    'family' => 'claude-5',
    'features' => ['completion'],
    'price' => [
      'in' => 5.00,
      'out' => 25.00,
    ],
    'type' => 'token',
    'unit' => 1 / 1000000,
    'maxCompletionTokens' => 128000,
    'maxContextualTokens' => 1000000,
    'finetune' => false,
    // Adaptive thinking (no extended-thinking param). Non-default temperature/
    // top_p/top_k are rejected, same as the other Claude 5 models.
    'tags' => ['core', 'chat', 'vision', 'files', 'functions', 'reasoning', 'mcp', 'no-temperature', 'latest'],
    'tools' => ['code_interpreter', 'thinking', 'web_search']
  ],
  [
    'model' => 'claude-opus-4-8',
    'name' => 'Claude Opus 4.8',
    'family' => 'claude-4',
    'features' => ['completion'],
    'price' => [
      'in' => 5.00,
      'out' => 25.00,
    ],
    'type' => 'token',
    'unit' => 1 / 1000000,
    'maxCompletionTokens' => 128000,
    'maxContextualTokens' => 1000000,
    'finetune' => false,
    'tags' => ['core', 'chat', 'vision', 'files', 'functions', 'reasoning', 'mcp', 'no-temperature'],
    'tools' => ['code_interpreter', 'thinking', 'web_search']
  ],
  [
    'model' => 'claude-opus-4-7',
    'name' => 'Claude Opus 4.7',
    'family' => 'claude-4',
    'features' => ['completion'],
    'price' => [
      'in' => 5.00,
      'out' => 25.00,
    ],
    'type' => 'token',
    'unit' => 1 / 1000000,
    'maxCompletionTokens' => 128000,
    'maxContextualTokens' => 1000000,
    'finetune' => false,
    'tags' => ['core', 'chat', 'vision', 'files', 'functions', 'reasoning', 'mcp', 'no-temperature'],
    'tools' => ['code_interpreter', 'thinking', 'web_search']
  ],
  [
    'model' => 'claude-opus-4-6',
    'name' => 'Claude Opus 4.6',
    'family' => 'claude-4',
    'features' => ['completion'],
    'price' => [
      'in' => 5.00,
      'out' => 25.00,
    ],
    'type' => 'token',
    'unit' => 1 / 1000000,
    'maxCompletionTokens' => 128000,
    'maxContextualTokens' => 1000000,
    'finetune' => false,
    'tags' => ['core', 'chat', 'vision', 'files', 'functions', 'reasoning', 'mcp'],
    'tools' => ['code_interpreter', 'thinking', 'web_search']
  ],
  [
    'model' => 'claude-opus-4-5',
    'name' => 'Claude Opus 4.5',
    'family' => 'claude-4',
    'features' => ['completion'],
    'price' => [
      'in' => 5.00,
      'out' => 25.00,
    ],
    'type' => 'token',
    'unit' => 1 / 1000000,
    'maxCompletionTokens' => 64000,
    'maxContextualTokens' => 200000,
    'finetune' => false,
    'tags' => ['core', 'chat', 'vision', 'files', 'functions', 'reasoning', 'mcp'],
    'tools' => ['code_interpreter', 'thinking', 'web_search']
  ],
  [
    'model' => 'claude-sonnet-5',
    'name' => 'Claude Sonnet 5',
    'family' => 'claude-5',
    'features' => ['completion'],
    // Anthropic made the $2/$10 introductory pricing permanent in August 2026.
    'price' => [
      'in' => 2.00,
      'out' => 10.00,
    ],
    'type' => 'token',
    'unit' => 1 / 1000000,
    'maxCompletionTokens' => 128000,
    'maxContextualTokens' => 1000000,
    'finetune' => false,
    // Adaptive thinking is always on (no disabled mode, no manual budget, no
    // assistant prefill). Non-default temperature/top_p/top_k are rejected; the
    // 'no-temperature' tag stops us sending temperature, and we never send top_p/top_k.
    'tags' => ['core', 'chat', 'vision', 'files', 'functions', 'reasoning', 'mcp', 'no-temperature', 'latest'],
    'tools' => ['code_interpreter', 'thinking', 'web_search']
  ],
  [
    'model' => 'claude-sonnet-4-6',
    'name' => 'Claude Sonnet 4.6',
    'family' => 'claude-4',
    'features' => ['completion'],
    'price' => [
      'in' => 3.00,
      'out' => 15.00,
    ],
    'type' => 'token',
    'unit' => 1 / 1000000,
    'maxCompletionTokens' => 64000,
    'maxContextualTokens' => 1000000,
    'finetune' => false,
    'tags' => ['core', 'chat', 'vision', 'files', 'functions', 'reasoning', 'mcp'],
    'tools' => ['code_interpreter', 'thinking', 'web_search']
  ],
  [
    'model' => 'claude-sonnet-4-5-20250929',
    'name' => 'Claude Sonnet 4.5 (2025/09/29)',
    'family' => 'claude-4',
    'features' => ['completion'],
    'price' => [
      'in' => 3.00,
      'out' => 15.00,
    ],
    'type' => 'token',
    'unit' => 1 / 1000000,
    'maxCompletionTokens' => 64000,
    'maxContextualTokens' => 200000,
    'finetune' => false,
    'tags' => ['core', 'chat', 'vision', 'files', 'functions', 'reasoning', 'mcp'],
    'tools' => ['code_interpreter', 'thinking', 'web_search']
  ],
  [
    'model' => 'claude-sonnet-4-5',
    'name' => 'Claude Sonnet 4.5',
    'family' => 'claude-4',
    'features' => ['completion'],
    'price' => [
      'in' => 3.00,
      'out' => 15.00,
    ],
    'type' => 'token',
    'unit' => 1 / 1000000,
    'maxCompletionTokens' => 64000,
    'maxContextualTokens' => 200000,
    'finetune' => false,
    'tags' => ['core', 'chat', 'vision', 'files', 'functions', 'reasoning', 'mcp'],
    'tools' => ['code_interpreter', 'thinking', 'web_search']
  ],
  // Claude Opus 4.1 was retired by Anthropic on 2026-08-05 (requests error) and removed
  // from this list on 2026-09-03. Sites still pointing at it get the usual unknown-model error.
  [
    'model' => 'claude-haiku-4-5-20251001',
    'name' => 'Claude Haiku 4.5 (2025/10/01)',
    'family' => 'claude-4',
    'features' => ['completion'],
    'price' => [
      'in' => 1.00,
      'out' => 5.00,
    ],
    'type' => 'token',
    'unit' => 1 / 1000000,
    'maxCompletionTokens' => 64000,
    'maxContextualTokens' => 200000,
    'finetune' => false,
    'tags' => ['core', 'chat', 'vision', 'files', 'functions', 'reasoning', 'mcp'],
    'tools' => ['code_interpreter', 'thinking', 'web_search']
  ],
  [
    'model' => 'claude-haiku-4-5',
    'name' => 'Claude Haiku 4.5',
    'family' => 'claude-4',
    'features' => ['completion'],
    'price' => [
      'in' => 1.00,
      'out' => 5.00,
    ],
    'type' => 'token',
    'unit' => 1 / 1000000,
    'maxCompletionTokens' => 64000,
    'maxContextualTokens' => 200000,
    'finetune' => false,
    'tags' => ['core', 'chat', 'vision', 'files', 'functions', 'reasoning', 'mcp', 'latest'],
    'tools' => ['code_interpreter', 'thinking', 'web_search']
  ],
] );

define( 'MWAI_PERPLEXITY_MODELS', [
  [
    'model' => 'sonar-pro',
    'name' => 'Sonar Pro',
    'family' => 'sonar',
    'features' => ['completion'],
    'price' => [
      'in' => 3.00,
      'out' => 15.00,
      'search' => 5.00,
    ],
    'type' => 'token',
    'unit' => 1 / 1000000,
    'searchUnit' => 1 / 1000,
    'maxCompletionTokens' => 8192,
    'maxContextualTokens' => 200000,
    'finetune' => false,
    'tags' => ['core', 'chat'],
  ],
  [
    'model' => 'sonar',
    'name' => 'Sonar',
    'family' => 'sonar',
    'features' => ['completion'],
    'price' => [
      'in' => 1.00,
      'out' => 1.00,
      'search' => 5.00,
    ],
    'type' => 'token',
    'unit' => 1 / 1000000,
    'searchUnit' => 1 / 1000,
    'maxCompletionTokens' => 4096,
    'maxContextualTokens' => 127000,
    'finetune' => false,
    'tags' => ['core', 'chat'],
  ],
] );

// Mistral AI Models
// Models are fetched dynamically from the Mistral API
define( 'MWAI_MISTRAL_MODELS', [] );

// xAI (Grok) Models
// Models are fetched dynamically from the xAI API. The fallback list below mirrors the
// chat-capable models that xAI publishes on https://docs.x.ai/docs/models, used only when
// the dynamic fetch fails (e.g. invalid key during preflight).
define( 'MWAI_XAI_MODELS', [
  [
    'model' => 'grok-4',
    'name' => 'Grok 4',
    'family' => 'grok',
    'features' => [ 'completion', 'functions' ],
    'price' => [ 'in' => 3.00, 'out' => 15.00 ],
    'type' => 'token',
    'unit' => 1 / 1000000,
    'maxCompletionTokens' => 16384,
    'maxContextualTokens' => 256000,
    'tags' => [ 'core', 'chat', 'functions', 'vision', 'reasoning' ],
  ],
  [
    'model' => 'grok-4-fast',
    'name' => 'Grok 4 Fast',
    'family' => 'grok',
    'features' => [ 'completion', 'functions' ],
    'price' => [ 'in' => 0.20, 'out' => 0.50 ],
    'type' => 'token',
    'unit' => 1 / 1000000,
    'maxCompletionTokens' => 16384,
    'maxContextualTokens' => 256000,
    'tags' => [ 'core', 'chat', 'functions', 'vision', 'reasoning' ],
  ],
  [
    'model' => 'grok-code-fast-1',
    'name' => 'Grok Code Fast',
    'family' => 'grok',
    'features' => [ 'completion', 'functions' ],
    'price' => [ 'in' => 0.20, 'out' => 1.50 ],
    'type' => 'token',
    'unit' => 1 / 1000000,
    'maxCompletionTokens' => 16384,
    'maxContextualTokens' => 256000,
    'tags' => [ 'core', 'chat', 'functions' ],
  ],
  [
    'model' => 'grok-3-mini',
    'name' => 'Grok 3 Mini',
    'family' => 'grok',
    'features' => [ 'completion', 'functions' ],
    'price' => [ 'in' => 0.30, 'out' => 0.50 ],
    'type' => 'token',
    'unit' => 1 / 1000000,
    'maxCompletionTokens' => 16384,
    'maxContextualTokens' => 131072,
    'tags' => [ 'core', 'chat', 'functions', 'reasoning' ],
  ],
] );
