<?php

class MeowPro_MWAI_ContentAware {
  private $core = null;

  public function __construct( $core ) {
    $this->core = $core;
    add_filter( 'mwai_chatbot_params', [ $this, 'chatbot_params' ] );
  }

  public function chatbot_params( $params ) {
    // The current page's placeholders ({CONTENT}, {TITLE}, {URL}, {EXCERPT}) resolve
    // whenever they appear in the instructions; there is no longer a toggle for it.
    // Prompt mode opts out, as it strips context-related features before the query.
    if ( isset( $params['mode'] ) && $params['mode'] === 'prompt' ) {
      return $params;
    }
    $instructions = isset( $params['instructions'] ) ? $params['instructions'] : '';
    $hasPlaceholder = strpos( $instructions, '{CONTENT}' ) !== false
      || strpos( $instructions, '{EXCERPT}' ) !== false
      || strpos( $instructions, '{TITLE}' ) !== false
      || strpos( $instructions, '{URL}' ) !== false;
    if ( !$hasPlaceholder ) {
      return $params;
    }
    $post = get_post( isset( $params['contextId'] ) ? $params['contextId'] : null );
    if ( empty( $post ) ) {
      return $params;
    }

    // contextId can be supplied by the client, so only inject content the
    // requester is actually allowed to see: a publicly-viewable post (with its
    // password entered, if any) or one the current user can read. Without this a
    // visitor could point a content-aware chatbot at a draft, private or trashed
    // post and extract it through the AI. Guests viewing a normal published page
    // are unaffected (that post is publicly viewable).
    $publiclyViewable = is_post_publicly_viewable( $post ) && !post_password_required( $post );
    if ( !$publiclyViewable && !current_user_can( 'read_post', $post->ID ) ) {
      return $params;
    }

    // Content
    if ( strpos( $params['instructions'], '{CONTENT}' ) !== false ) {
      $content = $this->core->get_post_content( $post->ID );

      // If WooCommerce, get the Product Description
      if ( class_exists( 'WooCommerce' ) ) {
        /** @disregard P1010 WooCommerce helper loaded only when the plugin is active */
        if ( is_product() ) {
          global $product;
          $shortDescription = $this->core->clean_text( $product->get_short_description() );
          if ( !empty( $shortDescription ) ) {
            $content .= $shortDescription;
          }
        }
      }
      $content = $this->core->clean_sentences( $content );
      $content = apply_filters( 'mwai_contentaware_content', $content, $post );
      $params['instructions'] = str_replace( '{CONTENT}', $content, $params['instructions'] );
    }

    // Excerpt
    if ( strpos( $params['instructions'], '{EXCERPT}' ) !== false ) {
      if ( !empty( $post ) ) {
        $excerpt = $this->core->clean_text( $post->post_excerpt );
        $params['instructions'] = str_replace( '{EXCERPT}', $excerpt, $params['instructions'] );
      }
    }

    // Title
    if ( strpos( $params['instructions'], '{TITLE}' ) !== false ) {
      $title = $this->core->clean_text( $post->post_title );
      $params['instructions'] = str_replace( '{TITLE}', $title, $params['instructions'] );
    }

    // URL
    if ( strpos( $params['instructions'], '{URL}' ) !== false ) {
      $url = get_permalink( $post->ID );
      $params['instructions'] = str_replace( '{URL}', $url, $params['instructions'] );
    }

    return $params;
  }
}
