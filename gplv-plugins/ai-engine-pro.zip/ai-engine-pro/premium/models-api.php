<?php

/**
 * Models API: the site's AI models behind an OpenAI-compatible API, so coding agents
 * like OpenCode can use them with a single key while the provider keys stay here.
 *
 * Requests are forwarded to each provider's own OpenAI-compatible endpoint rather
 * than rebuilt through AI Engine's query pipeline: tool calls, streaming and every
 * other field then work as the client sent them, for every supported provider.
 * Usage limits are checked before the call and usage is logged in Insights after.
 */
class MeowPro_MWAI_ModelsApi {
  private $core = null;
  private $namespace = 'mwai-openai/v1';
  private const SCOPE = 'models-api';

  // Providers that expose an OpenAI-compatible Chat Completions endpoint.
  private const SUPPORTED_TYPES = [ 'openai', 'anthropic', 'google', 'openrouter', 'mistral', 'xai', 'perplexity', 'ovh', 'custom' ];

  // Providers known to accept stream_options, needed to get usage at the end of a stream.
  private const STREAM_USAGE_TYPES = [ 'openai', 'openrouter', 'xai', 'google', 'anthropic' ];

  public function __construct( $core ) {
    $this->core = $core;
    add_action( 'rest_api_init', [ $this, 'rest_api_init' ] );
  }

  public function rest_api_init() {
    register_rest_route( $this->namespace, '/models', [
      'methods' => 'GET',
      'callback' => [ $this, 'rest_models' ],
      'permission_callback' => [ $this, 'check_api_key' ],
    ] );
    register_rest_route( $this->namespace, '/chat/completions', [
      'methods' => 'POST',
      'callback' => [ $this, 'rest_chat_completions' ],
      'permission_callback' => [ $this, 'check_api_key' ],
    ] );
    register_rest_route( $this->namespace, '/responses', [
      'methods' => 'POST',
      'callback' => [ $this, 'rest_responses' ],
      'permission_callback' => [ $this, 'check_api_key' ],
    ] );
    register_rest_route( 'mwai/v1', '/models_api/setup', [
      'methods' => 'POST',
      'callback' => [ $this, 'rest_setup' ],
      'permission_callback' => [ $this->core, 'can_access_settings' ],
    ] );
  }

  #region Authentication

  public function check_api_key( WP_REST_Request $request ) {
    $expected = (string) $this->core->get_option( 'models_api_key', '' );
    $header = (string) $request->get_header( 'authorization' );
    // Some Apache setups only pass the header through the rewrite variable.
    if ( $header === '' && !empty( $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ) ) {
      $header = (string) $_SERVER['REDIRECT_HTTP_AUTHORIZATION'];
    }
    $key = trim( (string) preg_replace( '/^Bearer\s+/i', '', $header ) );
    if ( $expected === '' || $key === '' || !hash_equals( $expected, $key ) ) {
      return new WP_Error( 'invalid_api_key', 'Invalid or missing API key. Use the key from AI Engine → Modules → Models API.', [ 'status' => 401 ] );
    }
    // Queries run as the site administrator, like the Public API, so limits and
    // Insights attribute them to a real account.
    $admin = $this->core->get_admin_user();
    if ( $admin ) {
      wp_set_current_user( $admin->ID );
    }
    return true;
  }

  #endregion

  #region Models

  public function rest_models( WP_REST_Request $request ) {
    $data = [];
    foreach ( $this->list_models() as $entry ) {
      $data[] = [
        'id' => $entry['id'],
        'object' => 'model',
        'created' => 0,
        'owned_by' => $entry['env']['name'] ?? $entry['env']['type'],
      ];
    }
    return new WP_REST_Response( [ 'object' => 'list', 'data' => $data ], 200 );
  }

  /**
  * Every chat model of every supported environment, named "<environment>/<model>" so
  * the same model in two environments (OpenAI and OpenRouter, say) stays distinct.
  */
  private function list_models(): array {
    $envs = $this->core->get_option( 'ai_envs' ) ?? [];
    $customModels = $this->core->get_option( 'ai_models' ) ?? [];
    $slugs = $this->env_slugs( $envs );
    $list = [];
    foreach ( $envs as $env ) {
      if ( empty( $env['id'] ) || !in_array( $env['type'] ?? '', self::SUPPORTED_TYPES, true ) ) {
        continue;
      }
      // Fetched or custom models are stored per environment. Only the providers with a
      // built-in list fall back to the engine, so listing never triggers a remote call.
      $models = array_values( array_filter( $customModels, function ( $m ) use ( $env ) {
        return ( $m['envId'] ?? null ) === $env['id'];
      } ) );
      if ( empty( $models ) && in_array( $env['type'], [ 'openai', 'anthropic', 'perplexity', 'xai' ], true ) ) {
        try {
          $models = Meow_MWAI_Engines_Factory::get( $this->core, $env['id'] )->get_models();
        }
        catch ( Exception $e ) {
          $models = [];
        }
      }
      foreach ( $models as $model ) {
        if ( empty( $model['model'] ) || !$this->is_chat_model( $model ) ) {
          continue;
        }
        $list[] = [ 'id' => $slugs[ $env['id'] ] . '/' . $model['model'], 'env' => $env, 'model' => $model ];
      }
    }
    return $list;
  }

  private function is_chat_model( array $model ): bool {
    $features = $model['features'] ?? [];
    $tags = $model['tags'] ?? [];
    return in_array( 'completion', $features, true ) && !in_array( 'deprecated', $tags, true );
  }

  private function env_slugs( array $envs ): array {
    $slugs = [];
    foreach ( $envs as $env ) {
      if ( empty( $env['id'] ) ) {
        continue;
      }
      $slug = sanitize_title( $env['name'] ?? '' );
      if ( $slug === '' ) {
        $slug = sanitize_title( $env['type'] ?? 'env' );
      }
      if ( in_array( $slug, $slugs, true ) ) {
        $slug .= '-' . $env['id'];
      }
      $slugs[ $env['id'] ] = $slug;
    }
    return $slugs;
  }

  private function find_model( string $id ): ?array {
    foreach ( $this->list_models() as $entry ) {
      if ( $entry['id'] === $id ) {
        return $entry;
      }
    }
    return null;
  }

  #endregion

  #region Chat Completions

  public function rest_chat_completions( WP_REST_Request $request ) {
    return $this->forward( $request, 'chat/completions' );
  }

  /**
  * OpenAI only. Its newest models refuse tools together with a reasoning effort on
  * Chat Completions, and clients built on the OpenAI SDK (OpenCode's OpenAI provider)
  * use this endpoint instead.
  */
  public function rest_responses( WP_REST_Request $request ) {
    return $this->forward( $request, 'responses' );
  }

  private function forward( WP_REST_Request $request, string $path ) {
    $body = json_decode( $request->get_body(), true );
    $isChat = $path === 'chat/completions';
    $hasInput = $isChat ? ( !empty( $body['messages'] ) && is_array( $body['messages'] ) ) : isset( $body['input'] );
    if ( !is_array( $body ) || empty( $body['model'] ) || !$hasInput ) {
      $needs = $isChat ? 'a list of messages' : 'an input';
      return $this->error( 400, 'invalid_request_error', "The request needs a model and {$needs}." );
    }
    $entry = $this->find_model( (string) $body['model'] );
    if ( !$entry ) {
      return $this->error( 404, 'model_not_found', "The model '{$body['model']}' is not available on this site. GET /models lists the ones that are." );
    }
    $env = $entry['env'];
    $modelId = $entry['model']['model'];
    if ( !$isChat && $env['type'] !== 'openai' ) {
      return $this->error( 400, 'invalid_request_error', 'The Responses API is only available for OpenAI models. Use /chat/completions for this one.' );
    }
    $upstream = $this->upstream_base( $env );
    if ( empty( $upstream ) || empty( $env['apikey'] ) ) {
      return $this->error( 500, 'configuration_error', "The environment '{$env['name']}' has no API key or endpoint in AI Engine." );
    }

    // Limits and the Security module (banned IPs) apply exactly as for any AI Engine query.
    $query = $this->build_query( $env, $modelId );
    $allowed = apply_filters( 'mwai_ai_allowed', true, $query, $this->core->get_option( 'limits' ) );
    if ( $allowed !== true ) {
      // The limit messages are written for chatbot visitors, so API clients get their own.
      if ( is_wp_error( $allowed ) && $allowed->get_error_code() === 'mwai_over_limit' ) {
        return $this->error( 429, 'insufficient_quota', 'This site reached its AI spending limit. An administrator can raise it in AI Engine → Insights → Limits.' );
      }
      $message = is_wp_error( $allowed ) ? $allowed->get_error_message() : ( is_string( $allowed ) ? $allowed : 'This request is not allowed.' );
      return $this->error( 403, 'permission_denied', $message );
    }

    $body['model'] = $modelId;
    // OpenAI's current models refuse max_tokens, which generic OpenAI clients (the AI SDK
    // behind OpenCode, for one) still send.
    if ( $isChat && $env['type'] === 'openai' && isset( $body['max_tokens'] ) && !isset( $body['max_completion_tokens'] ) ) {
      $body['max_completion_tokens'] = $body['max_tokens'];
      unset( $body['max_tokens'] );
    }
    if ( $isChat && $env['type'] === 'google' ) {
      $body['messages'] = $this->restore_thought_signatures( $body['messages'] );
    }
    $url = $upstream . '/' . $path;
    $headers = $this->upstream_headers( $env );

    if ( !empty( $body['stream'] ) ) {
      // Responses streams always end with the usage; Chat Completions only when asked.
      if ( $isChat && in_array( $env['type'], self::STREAM_USAGE_TYPES, true ) && !isset( $body['stream_options'] ) ) {
        $body['stream_options'] = [ 'include_usage' => true ];
      }
      $this->stream( $url, $headers, $body, $env, $modelId );
      die();
    }

    $response = wp_remote_post( $url, [
      'headers' => $headers,
      'body' => wp_json_encode( $body ),
      'timeout' => 600,
      'sslverify' => MWAI_SSL_VERIFY,
    ] );
    if ( is_wp_error( $response ) ) {
      return $this->error( 502, 'upstream_error', $response->get_error_message() );
    }
    $status = (int) wp_remote_retrieve_response_code( $response );
    $data = json_decode( wp_remote_retrieve_body( $response ), true );
    if ( !is_array( $data ) ) {
      return $this->error( 502, 'upstream_error', 'The provider returned a response that is not JSON.' );
    }
    if ( $status === 200 && !empty( $data['usage'] ) ) {
      $this->record_usage( $env, $modelId, $data['usage'] );
    }
    if ( $status === 200 && $env['type'] === 'google' ) {
      $this->remember_thought_signatures( $data['choices'][0]['message']['tool_calls'] ?? [] );
    }
    return new WP_REST_Response( $data, $status );
  }

  /**
  * Relays the provider's event stream to the client as it arrives, and keeps the last
  * usage block it sees so the call can be logged once the stream ends.
  */
  private function stream( string $url, array $headers, array $body, array $env, string $modelId ) {
    if ( function_exists( 'set_time_limit' ) ) {
      @set_time_limit( 0 );
    }
    while ( ob_get_level() > 0 ) {
      ob_end_flush();
    }

    $status = 0;
    $started = false;
    $errorBody = '';
    $pending = '';
    $usage = null;
    $toolCalls = [];
    $isGoogle = $env['type'] === 'google';

    $curlHeaders = [];
    foreach ( $headers as $name => $value ) {
      $curlHeaders[] = $name . ': ' . $value;
    }

    $ch = curl_init( $url );
    curl_setopt_array( $ch, [
      CURLOPT_POST => true,
      CURLOPT_POSTFIELDS => wp_json_encode( $body ),
      CURLOPT_HTTPHEADER => $curlHeaders,
      CURLOPT_CONNECTTIMEOUT => 20,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_SSL_VERIFYPEER => MWAI_SSL_VERIFY,
      CURLOPT_SSL_VERIFYHOST => MWAI_SSL_VERIFY ? 2 : 0,
      CURLOPT_HEADERFUNCTION => function ( $ch, $line ) use ( &$status ) {
        if ( preg_match( '#^HTTP/\S+\s+(\d{3})#', $line, $m ) ) {
          $status = (int) $m[1];
        }
        return strlen( $line );
      },
      CURLOPT_WRITEFUNCTION => function ( $ch, $chunk ) use ( &$status, &$started, &$errorBody, &$pending, &$usage, &$toolCalls, $isGoogle ) {
        if ( $status >= 400 ) {
          $errorBody .= $chunk;
          return strlen( $chunk );
        }
        if ( !$started ) {
          status_header( 200 );
          header( 'Content-Type: text/event-stream' );
          header( 'Cache-Control: no-cache' );
          header( 'X-Accel-Buffering: no' );
          $started = true;
        }
        echo $chunk;
        flush();

        $pending .= $chunk;
        while ( ( $pos = strpos( $pending, "\n" ) ) !== false ) {
          $line = trim( substr( $pending, 0, $pos ) );
          $pending = substr( $pending, $pos + 1 );
          if ( strpos( $line, 'data:' ) === 0 ) {
            $json = json_decode( trim( substr( $line, 5 ) ), true );
            // Chat Completions puts usage on the last chunk, Responses on response.completed.
            $found = $json['usage'] ?? ( $json['response']['usage'] ?? null );
            if ( !empty( $found ) ) {
              $usage = $found;
            }
            if ( $isGoogle && !empty( $json['choices'][0]['delta']['tool_calls'] ) ) {
              $toolCalls = array_merge( $toolCalls, $json['choices'][0]['delta']['tool_calls'] );
            }
          }
        }
        // Stop the provider when the client leaves, so no tokens are spent for nobody.
        return connection_aborted() ? 0 : strlen( $chunk );
      },
    ] );
    curl_exec( $ch );
    $curlError = curl_error( $ch );
    curl_close( $ch );

    if ( !$started ) {
      $code = $status >= 400 ? $status : 502;
      $decoded = json_decode( $errorBody, true );
      $payload = is_array( $decoded ) ? $decoded : [ 'error' => [
        'message' => $curlError ?: ( trim( $errorBody ) ?: 'The provider did not answer.' ),
        'type' => 'upstream_error',
      ] ];
      status_header( $code );
      header( 'Content-Type: application/json' );
      echo wp_json_encode( $payload );
      return;
    }
    if ( $usage ) {
      $this->record_usage( $env, $modelId, $usage );
    }
    if ( $toolCalls ) {
      $this->remember_thought_signatures( $toolCalls );
    }
  }

  #endregion

  #region Gemini Thought Signatures

  /**
  * Gemini signs each tool call it makes and refuses the next request if the signature
  * is not sent back. Generic OpenAI clients (the AI SDK behind OpenCode) drop that
  * extra field when they replay the conversation, so the signatures are kept here
  * for a day, by tool call ID, and put back on the way out.
  */
  private function remember_thought_signatures( array $toolCalls ) {
    foreach ( $toolCalls as $call ) {
      $signature = $call['extra_content']['google']['thought_signature'] ?? null;
      if ( !empty( $call['id'] ) && !empty( $signature ) ) {
        set_transient( 'mwai_models_api_sig_' . md5( $call['id'] ), $signature, DAY_IN_SECONDS );
      }
    }
  }

  private function restore_thought_signatures( array $messages ): array {
    foreach ( $messages as &$message ) {
      if ( ( $message['role'] ?? '' ) !== 'assistant' || empty( $message['tool_calls'] ) || !is_array( $message['tool_calls'] ) ) {
        continue;
      }
      foreach ( $message['tool_calls'] as &$call ) {
        if ( !empty( $call['extra_content']['google']['thought_signature'] ) || empty( $call['id'] ) ) {
          continue;
        }
        $signature = get_transient( 'mwai_models_api_sig_' . md5( $call['id'] ) );
        // Google documents this placeholder for calls whose signature is unknown.
        $call['extra_content']['google']['thought_signature'] = $signature ?: 'skip_thought_signature_validator';
      }
      unset( $call );
    }
    unset( $message );
    return $messages;
  }

  #endregion

  #region Providers

  private function upstream_base( array $env ): ?string {
    switch ( $env['type'] ) {
      case 'openai':
        $base = apply_filters( 'mwai_openai_endpoint', 'https://api.openai.com/v1', $env );
        break;
      case 'anthropic':
        $base = apply_filters( 'mwai_anthropic_endpoint', 'https://api.anthropic.com/v1', $env );
        break;
      case 'google':
        $base = 'https://generativelanguage.googleapis.com/v1beta/openai';
        break;
      case 'openrouter':
        $base = apply_filters( 'mwai_openrouter_endpoint', 'https://openrouter.ai/api/v1', $env );
        break;
      case 'mistral':
        $base = apply_filters( 'mwai_mistral_endpoint', 'https://api.mistral.ai/v1', $env );
        break;
      case 'xai':
        $base = apply_filters( 'mwai_xai_endpoint', 'https://api.x.ai/v1', $env );
        break;
      case 'perplexity':
        $base = apply_filters( 'mwai_perplexity_endpoint', 'https://api.perplexity.ai', $env );
        break;
      case 'ovh':
        $endpoint = !empty( $env['endpoint'] ) ? $env['endpoint'] : 'https://oai.endpoints.kepler.ai.cloud.ovh.net';
        $base = apply_filters( 'mwai_ovh_endpoint', trailingslashit( $endpoint ) . 'v1', $env );
        break;
      case 'custom':
        $base = apply_filters( 'mwai_custom_endpoint', !empty( $env['endpoint'] ) ? $env['endpoint'] : 'http://localhost:11434/v1', $env );
        break;
      default:
        return null;
    }
    return rtrim( (string) $base, '/' );
  }

  private function upstream_headers( array $env ): array {
    $headers = [
      'Content-Type' => 'application/json',
      'Authorization' => 'Bearer ' . $env['apikey'],
    ];
    if ( $env['type'] === 'openai' && !empty( $env['organizationId'] ) ) {
      $headers['OpenAI-Organization'] = $env['organizationId'];
    }
    if ( $env['type'] === 'openrouter' ) {
      $headers['HTTP-Referer'] = get_site_url();
      $headers['X-Title'] = 'AI Engine';
    }
    return $headers;
  }

  #endregion

  #region Usage

  private function build_query( array $env, string $modelId ): Meow_MWAI_Query_Text {
    $query = new Meow_MWAI_Query_Text( '' );
    $query->set_scope( self::SCOPE );
    $query->set_env_id( $env['id'] );
    $query->set_model( $modelId );
    return $query;
  }

  private function record_usage( array $env, string $modelId, array $usage ) {
    global $mwai_stats;
    if ( empty( $mwai_stats ) ) {
      return;
    }
    try {
      $query = $this->build_query( $env, $modelId );
      $reply = new Meow_MWAI_Reply( $query );
      $reply->set_usage( [
        'prompt_tokens' => (int) ( $usage['prompt_tokens'] ?? $usage['input_tokens'] ?? 0 ),
        'completion_tokens' => (int) ( $usage['completion_tokens'] ?? $usage['output_tokens'] ?? 0 ),
        'total_tokens' => (int) ( $usage['total_tokens'] ?? 0 ),
      ] );
      $reply->set_usage_accuracy( 'full' );
      $mwai_stats->commit_stats_from_query( $query, $reply, [] );
    }
    catch ( Exception $e ) {
      Meow_MWAI_Logging::warn( 'Models API: could not log usage (' . $e->getMessage() . ').' );
    }
  }

  #endregion

  #region Setup

  /**
  * The OpenCode provider block for one environment, built from the same
  * model list the API serves, so the snippet in Settings always matches it.
  */
  public function rest_setup( WP_REST_Request $request ) {
    $params = $request->get_json_params();
    $envId = (string) ( $params['envId'] ?? '' );
    $env = $this->core->get_ai_env( $envId );
    if ( empty( $env ) || !in_array( $env['type'] ?? '', self::SUPPORTED_TYPES, true ) ) {
      return new WP_REST_Response( [ 'success' => false, 'message' => 'This environment cannot be used through the Models API.' ], 400 );
    }
    $slug = $this->env_slugs( $this->core->get_option( 'ai_envs' ) ?? [] )[ $envId ] ?? $envId;
    $models = [];
    foreach ( $this->list_models() as $entry ) {
      if ( $entry['env']['id'] !== $envId ) {
        continue;
      }
      $model = $entry['model'];
      $tags = $model['tags'] ?? [];
      $item = [ 'name' => ( $model['name'] ?? $model['model'] ) . ' (' . ( $entry['env']['name'] ?? $entry['env']['type'] ) . ')' ];
      if ( in_array( 'functions', $tags, true ) ) {
        $item['tool_call'] = true;
      }
      if ( in_array( 'reasoning', $tags, true ) ) {
        $item['reasoning'] = true;
      }
      if ( !empty( $model['maxContextualTokens'] ) && !empty( $model['maxCompletionTokens'] ) ) {
        $item['limit'] = [
          'context' => (int) $model['maxContextualTokens'],
          'output' => (int) $model['maxCompletionTokens'],
        ];
      }
      if ( in_array( 'vision', $tags, true ) ) {
        $item['modalities'] = [ 'input' => [ 'text', 'image' ], 'output' => [ 'text' ] ];
      }
      $models[ $entry['id'] ] = $item;
    }
    return new WP_REST_Response( [
      'success' => true,
      'baseUrl' => rest_url( $this->namespace ),
      // OpenCode's OpenAI provider talks to /responses, which OpenAI's newest models need for tools.
      'npm' => $env['type'] === 'openai' ? '@ai-sdk/openai' : '@ai-sdk/openai-compatible',
      'providerId' => 'ai-engine-' . $slug,
      'providerName' => 'AI Engine (' . ( $env['name'] ?? $env['type'] ) . ')',
      'models' => $models,
    ], 200 );
  }

  #endregion

  private function error( int $status, string $type, string $message ): WP_REST_Response {
    return new WP_REST_Response( [ 'error' => [ 'message' => $message, 'type' => $type ] ], $status );
  }
}
