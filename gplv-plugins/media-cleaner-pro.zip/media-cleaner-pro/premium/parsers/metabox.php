<?php

add_action( 'wpmc_scan_once', 'wpmc_scan_once_metabox', 10, 0 );
add_action( 'wpmc_scan_postmeta', 'wpmc_scan_postmeta_metabox', 10, 1 );

function wpmc_scan_postmeta_metabox( $id ) {
  wpmc_scan_metabox_fields( rwmb_get_object_fields( $id ), $id, 'post', $id );
}

// Meta Box fields can also be attached to taxonomies, where the values live in termmeta.
function wpmc_scan_once_metabox() {
  global $wpdb, $wpmc;

  $fields_per_taxonomy = array();

  $wpmc->run_paged_parser( 'metabox-taxonomy-terms', function( $offset, $limit ) use ( $wpdb ) {
    return $wpdb->get_results( $wpdb->prepare(
      "SELECT DISTINCT x.term_taxonomy_id, x.term_id, x.taxonomy FROM {$wpdb->term_taxonomy} x
        INNER JOIN {$wpdb->termmeta} y ON x.term_id = y.term_id
        ORDER BY x.term_taxonomy_id ASC LIMIT %d, %d", $offset, $limit ) );
  }, function( $terms ) use ( &$fields_per_taxonomy ) {
    foreach ( $terms as $term ) {
      if ( !isset( $fields_per_taxonomy[ $term->taxonomy ] ) ) {
        $fields_per_taxonomy[ $term->taxonomy ] = rwmb_get_object_fields( $term->taxonomy, 'term' );
      }
      $fields = $fields_per_taxonomy[ $term->taxonomy ];
      if ( empty( $fields ) ) continue;
      wpmc_scan_metabox_fields( $fields, $term->term_id, 'term', $term->taxonomy . '_' . $term->term_id );
    }
  }, 50 );
}

function wpmc_scan_metabox_fields( $fields, $object_id, $object_type, $origin ) {
  global $wpmc;

  if ( empty( $fields ) || !is_array( $fields ) ) return;

  $object_id = (int)$object_id;
  $args = $object_type === 'post' ? null : array( 'object_type' => $object_type );
  $images_ids = array();
  $images_urls = array();

  foreach ( $fields as $field ) {
    $value = rwmb_get_value( $field['id'], $args, $object_id );

    // Advanced Image field
    if ( isset( $field['mime_type'] ) && $field['mime_type'] === 'image' && !empty( $value ) ) {
      foreach ( $value as $key => $image ) {
          if( !is_array( $image ) ) continue;
          $images_ids[] = $key;

          if( !isset( $image['url'] ) ) continue;
          $images_urls[] = $wpmc->clean_url( $image['url'] );
      }
    }

    // Single Image field: the value is one image array, not an array keyed by attachment ID.
    // Fall back on the raw meta, which is simply the attachment ID.
    if ( $field['type'] === 'single_image' ) {
      $image_id = is_array( $value ) && isset( $value['ID'] ) ? (int)$value['ID']
        : (int)( $object_type === 'term' ? get_term_meta( $object_id, $field['id'], true )
                                         : get_post_meta( $object_id, $field['id'], true ) );
      if ( $image_id ) {
        $images_ids[] = $image_id;
      }
      if ( is_array( $value ) && isset( $value['url'] ) ) {
        $images_urls[] = $wpmc->clean_url( $value['url'] );
      }
    }

    // Image field
    if ( $field['type'] === 'image' && !empty( $value ) ) {
      foreach ( $value as $key => $image ) {
          if( !is_array( $image ) ) continue;

          $images_ids[] = $key;

          if( !isset( $image['url'] ) ) continue;
          $images_urls[] = $wpmc->clean_url( $image['url'] );
      }
    }
  }

  $wpmc->add_reference_id( $images_ids, 'Meta Box (ID)', $origin );
  $wpmc->add_reference_url( $images_urls, 'Meta Box (URL)', $origin );
}

?>
