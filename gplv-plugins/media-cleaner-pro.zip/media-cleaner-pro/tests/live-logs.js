// Standalone check for the live console's folding: node tests/live-logs.js
// No framework. It fails if the toolbar totals can drift as the stream scrolls, or if blocks stop
// grouping the way the console draws them.
//
// LiveLogs.js is a React module, so the pure logic is lifted out of the source rather than
// imported. If it stops living between those markers, this stops finding it and fails.

const assert = require('node:assert');
const fs = require('node:fs');
const path = require('node:path');

const src = fs.readFileSync(path.join(__dirname, '../app/js/components/scan/LiveLogs.js'), 'utf8');
const start = src.indexOf('const emptyStats');
const end = src.indexOf('const formatMs');
assert.ok(start !== -1 && end > start, 'the folding logic still lives in LiveLogs.js');
// The cap lives with the other constants at the top, above the JSX this cannot parse.
const cap = src.match(/^const MAX_BLOCKS = \d+;$/m);
assert.ok(cap, 'MAX_BLOCKS still declared in LiveLogs.js');
const { emptyStats, foldEvent, blockEvents, MAX_BLOCKS } = new Function(
  `${cap[0]}\n${src.slice(start, end)}; return { emptyStats, foldEvent, blockEvents, MAX_BLOCKS };`
)();

const ev = (kind, extra = {}) => ({ kind, time: '03:26:22', text: kind, group: null, ...extra });

// A run long enough that the stream has dropped most of the blocks it saw. The totals describe the
// run, not the window, so nothing scrolling away may reduce them.
let stats = emptyStats();
const events = [];
for (let i = 0; i < 1000; i++) {
  events.push(ev('post', { postId: i, postType: 'page', text: `Title ${i}`, group: `post-${i}` }));
  events.push(ev('refs', { count: 3, text: 'references written' }));
  events.push(ev('post-done', { postId: i, ms: 12, group: `post-${i}` }));
}
events.push(ev('timing', { text: 'wpmc_scan_once_smartslider3', ms: 51200, queries: 90, group: 'wpmc_scan_once_smartslider3' }));
events.push(ev('timing', { text: 'wpmc_scan_widgets_maxmegamenu', ms: 1300, queries: 15, group: 'wpmc_scan_widgets_maxmegamenu' }));
events.push(ev('batch', { count: 5, queries: 812 }));
events.push(ev('batch', { count: 5, queries: 640 }));
events.push(ev('parser', { text: 'wpmc_scan_once_revslider', group: 'wpmc_scan_once_revslider' }));
for (const event of events) stats = foldEvent(stats, event);

assert.strictEqual(stats.posts, 1000, 'posts accumulate past the window');
assert.strictEqual(stats.refs, 3000, 'refs accumulate past the window');
// Batch events, not timings: timings only report the parsers that crossed the slow threshold.
assert.strictEqual(stats.queries, 1452, 'queries sum across batches');
assert.deepStrictEqual(stats.slowest, { name: 'wpmc_scan_once_smartslider3', ms: 51200 },
  'the slowest parser is kept, not the most recent');
// A timing is a result, not an activity, so it must not become "what is happening now".
assert.strictEqual(stats.now, 'wpmc_scan_once_revslider', 'current activity is the newest activity line');

// Folding is monotonic: replaying more events can never reduce a total.
const before = { ...stats };
for (const event of events.slice(0, 40)) stats = foldEvent(stats, event);
for (const key of ['posts', 'refs', 'queries']) {
  assert.ok(stats[key] >= before[key], `${key} never decreases`);
}

// -- blocks ----------------------------------------------------------------

// A parser and the events it emitted are one block. The timing lands on the header rather than
// becoming a row, because a row would just repeat it. References do both: the header totals them,
// the rows name them.
let blocks = blockEvents([], [
  ev('parser', { text: 'p1', group: 'p1' }),
  ev('refs', { count: 14, text: '2020/10/a.jpg, #142163 (+12 more)' }),
  ev('refs', { count: 11, text: '2020/10/b.jpg (+10 more)' }),
  ev('warn', { text: 'unbounded query' }),
  ev('timing', { text: 'p1', ms: 2400, queries: 9, group: 'p1' }),
]);
assert.strictEqual(blocks.length, 1, 'one parser, one block');
assert.strictEqual(blocks[0].refs, 25, 'references are totalled on the header');
assert.strictEqual(blocks[0].ms, 2400, 'the timing lands on the header');
assert.strictEqual(blocks[0].queries, 9, 'with its query count');
assert.deepStrictEqual(blocks[0].children.map(c => c.kind), ['refs', 'refs', 'warn'],
  'and the references still show as rows of their own');
assert.ok(blocks[0].children[0].text.includes('2020/10/a.jpg'),
  'each naming what it wrote');

// A post that did nothing notable is a single row: its completion carries the duration and
// nothing else, so it must not render a child that repeats the post.
blocks = blockEvents([], [
  ev('post', { postId: 1270, postType: 'dbclnr_fake_post', text: 'Fake Post', group: 'post-1270' }),
  ev('post-done', { postId: 1270, ms: 6, group: 'post-1270' }),
]);
assert.strictEqual(blocks.length, 1, 'a quiet post is one block');
assert.strictEqual(blocks[0].children.length, 0, 'and has no child row repeating itself');
assert.strictEqual(blocks[0].ms, 6, 'its duration is on the header');

// The same parser running on the next batch is a new block. A fast parser never reports a
// duration, so its block never seals -- nesting the next run inside it is what made the stream
// fill with copies of initialize_parsers.
blocks = blockEvents([], [
  ev('parser', { text: 'initialize_parsers', group: 'initialize_parsers' }),
  ev('parser', { text: 'initialize_parsers', group: 'initialize_parsers' }),
  ev('parser', { text: 'initialize_parsers', group: 'initialize_parsers' }),
]);
assert.strictEqual(blocks.length, 3, 'each run of a parser is its own block');
assert.ok(blocks.every(b => b.children.length === 0), 'and none nests inside another');

// Ungrouped events attach to whatever is open, which is how a warning ends up under the parser
// that tripped it rather than as a loose row.
blocks = blockEvents([], [
  ev('parser', { text: 'p1', group: 'p1' }),
  ev('error', { text: 'Timeout!' }),
]);
assert.strictEqual(blocks.length, 1, 'an error joins the open block');
assert.deepStrictEqual(blocks[0].children.map(c => c.kind), ['error'], 'as a row of its own');

// With nothing open it still has to appear, not vanish.
blocks = blockEvents([], [ev('error', { text: 'Timeout!' })]);
assert.strictEqual(blocks.length, 1, 'an orphan error still shows');

// A new batch starts a new block, and its ungrouped opening lines must land under it — not under
// the previous request's last item, which is still unsealed because that item never reported back.
blocks = blockEvents([], [
  ev('cleanup', { text: 'a.jpg', group: 'cleanup-1', hook: 'delete' }),
  ev('step', { text: 'wp_delete_attachment' }),
  ev('phase', { text: 'Cleanup: delete, 20 items' }),
  ev('step', { text: 'validate_issue_manifest' }),
]);
assert.strictEqual(blocks.length, 3, 'the new batch opens its own block');
assert.deepStrictEqual(blocks[0].children.map(c => c.text), ['wp_delete_attachment'],
  'the stalled item keeps only its own steps');
assert.strictEqual(blocks[1].head.kind, 'phase', 'the batch header comes next, in order');
assert.deepStrictEqual(blocks[2].head.text, 'validate_issue_manifest',
  'and what follows it starts after it, not before');

// Separators stand alone and adopt nothing.
blocks = blockEvents([], [
  ev('phase', { text: 'Extracting refs from content' }),
  ev('batch', { count: 5, queries: 812 }),
]);
assert.strictEqual(blocks.length, 2, 'phases and batches each stand alone');
assert.ok(blocks.every(b => b.children.length === 0), 'and adopt nothing');

// The stream is bounded, and it is the oldest blocks that go.
const many = [];
for (let i = 0; i < 400; i++) many.push(ev('phase', { text: `phase ${i}` }));
blocks = blockEvents([], many);
assert.strictEqual(blocks.length, MAX_BLOCKS, 'the stream is capped');
assert.strictEqual(blocks[blocks.length - 1].head.text, 'phase 399', 'keeping the newest');

console.log('ok');
