#### 1.1.2 (2020-08-25)

##### Bug Fixes

*  Default 16 bit depth broke the converter so I removed that line from the CLI command. (19e4f273)

#### 1.1.1 (2020-08-19)

##### New Features

*  Added bit depth and sample rate defaults. (2ff2df74)

### 1.1.0 (2020-08-18)

##### New Features

*  Made the plugin convert more dynamically and use the bitrate feature of ffmpeg. (38110fe8)

##### Bug Fixes

*  Duplicate filenames are now incrementing rather than overwriting. (769704e4)

#### 2.0.0 (2020-07-11)

##### New Features

*  Made the plugin convert more dynamically and use the bitrate feature of ffmpeg. (38110fe8)

