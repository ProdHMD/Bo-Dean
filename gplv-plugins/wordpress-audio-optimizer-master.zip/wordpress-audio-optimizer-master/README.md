# Auto convert audio files to a specified format 
A WordPress plugin which automatically converts any audio upload to a specified format. Requires FFMPEG and the ability to run shell commands through PHP.

## Defaults

File: Ogg

Bit rate: 160 kbps

Bit depth: 16

Sample rate: 44.1 kHz
